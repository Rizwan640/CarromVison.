package com.rizwan.carromvision.domain.algorithms

import com.rizwan.carromvision.domain.models.DetectedObject
import com.rizwan.carromvision.domain.models.ObjectType
import com.rizwan.carromvision.domain.models.Point2D
import com.rizwan.carromvision.domain.models.ShotSuggestion
import com.rizwan.carromvision.domain.models.ShotType
import kotlin.math.exp

/**
 * Evaluates and ranks candidate shots based on obstacle clearance, cut angle severity,
 * total travel distance, cushion reflections, striker scratch risk, and object detection confidence.
 * Never labels any shot as 100% guaranteed (confidence capped at 0.96).
 */
class ShotRankingEngine {

    fun calculateConfidenceScore(
        shotType: ShotType,
        targetCoin: DetectedObject,
        cutAngleDeg: Double,
        strikerToContactDist: Double,
        coinTotalTravelDist: Double,
        cushionCount: Int,
        obstacleCount: Int,
        strikerFinalPos: Point2D,
        pocketPositions: List<Point2D>
    ): Double {
        // 1. Cut-angle factor: 0° is ideal (1.0), > 72° drops sharply
        if (cutAngleDeg >= 78.0) return 0.12
        val cutFactor = 1.0 - (cutAngleDeg / 82.0) * (cutAngleDeg / 82.0)

        // 2. Travel distance factor: shorter paths suffer less angular dispersion
        val totalDist = strikerToContactDist + coinTotalTravelDist
        val distanceFactor = exp(-0.42 * totalDist).coerceIn(0.25, 1.0)

        // 3. Cushion complexity penalty
        val cushionFactor = when (cushionCount) {
            0 -> 1.0
            1 -> 0.78
            2 -> 0.56
            else -> 0.38
        }

        // 4. Obstacle blockage penalty
        val obstacleFactor = when (obstacleCount) {
            0 -> 1.0
            1 -> 0.28
            else -> 0.10
        }

        // 5. Striker foul (scratch) risk penalty if striker ends up inside/near a pocket
        val minPocketDist = pocketPositions.minOfOrNull { it.distanceTo(strikerFinalPos) } ?: 0.5
        val scratchPenalty = if (minPocketDist < 0.065) 0.55 else 1.0

        // 6. Queen priority bonus (subtle preference when paths are equally clear)
        val typeMultiplier = if (targetCoin.type == ObjectType.RED_QUEEN) 1.04 else 1.0

        val rawConfidence = targetCoin.confidence *
            cutFactor *
            (0.55 + 0.45 * distanceFactor) *
            cushionFactor *
            obstacleFactor *
            scratchPenalty *
            typeMultiplier

        // Cap at 0.96 so no unverified physical shot is ever labeled 100% guaranteed
        return rawConfidence.coerceIn(0.08, 0.96)
    }

    fun rankSuggestions(candidates: List<ShotSuggestion>): List<ShotSuggestion> {
        return candidates.sortedWith(
            compareByDescending<ShotSuggestion> { it.obstaclesOnPath.isEmpty() }
                .thenByDescending { it.confidenceScore }
                .thenBy { it.cushionCount }
                .thenBy { it.cutAngleDegrees }
        )
    }
}
