package com.rizwan.carromvision.core.vision

import android.graphics.Bitmap
import android.graphics.Color
import com.rizwan.carromvision.calibration.CalibrationProfile
import com.rizwan.carromvision.domain.models.Pocket
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Detects the 4 corner pockets in the perspective-warped square board bitmap
 * by scanning each corner quadrant for the dark circular pocket well.
 */
class PocketDetector {

    fun detectPockets(
        warpedBoardBitmap: Bitmap,
        calibrationProfile: CalibrationProfile = CalibrationProfile()
    ): List<Pocket> {
        val w = warpedBoardBitmap.width
        val h = warpedBoardBitmap.height
        if (w < 64 || h < 64) {
            return calibrationProfile.pockets
        }

        val searchZones = listOf(
            Triple(0, "Top-Left Pocket", Pair(0.015..0.14, 0.015..0.14)),
            Triple(1, "Top-Right Pocket", Pair(0.86..0.985, 0.015..0.14)),
            Triple(2, "Bottom-Right Pocket", Pair(0.86..0.985, 0.86..0.985)),
            Triple(3, "Bottom-Left Pocket", Pair(0.015..0.14, 0.86..0.985))
        )

        val detected = ArrayList<Pocket>(4)

        for ((id, name, zone) in searchZones) {
            val xRange = zone.first
            val yRange = zone.second
            val startX = (xRange.start * w).toInt().coerceIn(0, w - 1)
            val endX = (xRange.endInclusive * w).toInt().coerceIn(0, w - 1)
            val startY = (yRange.start * h).toInt().coerceIn(0, h - 1)
            val endY = (yRange.endInclusive * h).toInt().coerceIn(0, h - 1)

            var sumX = 0.0
            var sumY = 0.0
            var count = 0

            for (y in startY..endY step 2) {
                for (x in startX..endX step 2) {
                    val pixel = warpedBoardBitmap.getPixel(x, y)
                    val r = Color.red(pixel)
                    val g = Color.green(pixel)
                    val b = Color.blue(pixel)
                    val luma = 0.299 * r + 0.587 * g + 0.114 * b
                    // Dark pocket cavity threshold
                    if (luma < 48.0) {
                        sumX += x
                        sumY += y
                        count++
                    }
                }
            }

            if (count >= 12) {
                val centerXNorm = (sumX / count) / w.toDouble()
                val centerYNorm = (sumY / count) / h.toDouble()
                // Estimate normalized radius from pixel area: Area ≈ count * 4 = π * R^2
                val estimatedRadiusNorm = (kotlin.math.sqrt((count * 4.0) / Math.PI) / w.toDouble())
                    .coerceIn(0.034, 0.052)
                detected.add(
                    Pocket(
                        id = id,
                        name = name,
                        x = centerXNorm,
                        y = centerYNorm,
                        radius = estimatedRadiusNorm
                    )
                )
            } else {
                val fallback = calibrationProfile.pockets.getOrNull(id)
                    ?: Pocket(id, name, if (id == 1 || id == 2) 0.945 else 0.055, if (id >= 2) 0.945 else 0.055, 0.042)
                detected.add(fallback)
            }
        }

        return detected
    }
}
