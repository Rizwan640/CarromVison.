package com.rizwan.carromvision.ui.results

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rizwan.carromvision.domain.models.ShotSuggestion
import com.rizwan.carromvision.ui.WorkspaceUiState
import com.rizwan.carromvision.ui.theme.CharcoalCard
import com.rizwan.carromvision.ui.theme.DirectShotGreen
import com.rizwan.carromvision.ui.theme.SubtleCrimson
import com.rizwan.carromvision.ui.theme.SubtleGold
import com.rizwan.carromvision.ui.theme.TextSecondary

/**
 * Screen 4: Analysis Results — displays complete mathematical telemetry for the selected shot
 * and allows switching between all ranked candidate trajectories.
 */
@Composable
fun AnalysisResultsScreen(
    state: WorkspaceUiState,
    onSelectShotIndex: (Int) -> Unit,
    onBackToWorkspace: () -> Unit
) {
    val activeShot = state.primaryShot

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = onBackToWorkspace) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Column {
                    Text(
                        text = "Shot Analysis Results",
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Text(
                        text = "Ranked trajectories based on obstacle clearance, cut angle & cushion damping",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (activeShot == null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "No viable shot calculated yet. Run detection in the Analysis Workspace first.",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(20.dp)
                    )
                }
            } else {
                // Detailed Telemetry Card for Selected Shot
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Active Recommendation: ${activeShot.shotType.name.replace('_', ' ')}",
                            style = MaterialTheme.typography.titleMedium,
                            color = SubtleGold
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        TelemetryRow(
                            label = "Selected Target Coin",
                            value = "${activeShot.targetCoin.type.name} (${activeShot.targetCoin.id}) at (${fmt(activeShot.targetCoin.x)}, ${fmt(activeShot.targetCoin.y)})"
                        )
                        TelemetryRow(
                            label = "Suggested Pocket",
                            value = "${activeShot.targetPocket.name} (${fmt(activeShot.targetPocket.x)}, ${fmt(activeShot.targetPocket.y)})"
                        )
                        TelemetryRow(
                            label = "Recommended Shot Direction",
                            value = activeShot.summaryNote
                        )
                        TelemetryRow(
                            label = "Calculated Striker Angle",
                            value = "${"%.2f".format(activeShot.requiredAngleDegrees)}° (Cut Angle: ${"%.1f".format(activeShot.cutAngleDegrees)}°)"
                        )
                        TelemetryRow(
                            label = "Estimated Trajectory Segments",
                            value = "${activeShot.coinPath.size} coin segment(s), ${activeShot.cushionCount} cushion reflection(s)"
                        )
                        TelemetryRow(
                            label = "Predicted Collision Point",
                            value = "Ghost-Ball (${fmt(activeShot.requiredContactPoint.x)}, ${fmt(activeShot.requiredContactPoint.y)}) • Impact (${fmt(activeShot.collisionPrediction.impactPoint.x)}, ${fmt(activeShot.collisionPrediction.impactPoint.y)})"
                        )
                        TelemetryRow(
                            label = "Cushion Rebound Path",
                            value = if (activeShot.cushionCount == 0) {
                                "Direct line-of-sight (0 cushions)"
                            } else {
                                activeShot.coinPath.joinToString(" → ") {
                                    "(${fmt(it.start.x)},${fmt(it.start.y)}) to (${fmt(it.end.x)},${fmt(it.end.y)})"
                                }
                            }
                        )
                        TelemetryRow(
                            label = "Estimated Striker Final Position",
                            value = "(${fmt(activeShot.estimatedStrikerFinalPos.x)}, ${fmt(activeShot.estimatedStrikerFinalPos.y)})"
                        )
                        TelemetryRow(
                            label = "Confidence Score",
                            value = "${"%.1f".format(activeShot.confidenceScore * 100)}% ${if (activeShot.isUncertain) "(Requires Verification - High Cut/Cushion Complexity)" else "(Verified Geometric Clearance)"}"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Switch Between Calculated Shot Possibilities (${state.shotSuggestions.size})",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    itemsIndexed(state.shotSuggestions) { idx, candidate ->
                        CandidateShotRow(
                            index = idx,
                            shot = candidate,
                            isSelected = idx == state.activeShotIndex,
                            onClick = { onSelectShotIndex(idx) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryRow(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun CandidateShotRow(
    index: Int,
    shot: ShotSuggestion,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) SubtleGold.copy(alpha = 0.16f) else CharcoalCard
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "#${index + 1} ${shot.shotType.name.replace('_', ' ')} • ${shot.targetCoin.type.name} → ${shot.targetPocket.name}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isSelected) SubtleGold else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Angle: ${"%.1f".format(shot.requiredAngleDegrees)}° • Cut: ${"%.1f".format(shot.cutAngleDegrees)}° • Obstacles: ${shot.obstaclesOnPath.size}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${"%.0f".format(shot.confidenceScore * 100)}%",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (shot.confidenceScore >= 0.70) DirectShotGreen else SubtleCrimson,
                    fontWeight = FontWeight.Bold
                )
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Selected",
                        tint = SubtleGold,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }
        }
    }
}

private fun fmt(v: Double): String = "%.3f".format(v)
