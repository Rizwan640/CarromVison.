package com.rizwan.carromvision.core.geometry

import com.rizwan.carromvision.domain.models.DetectedObject
import com.rizwan.carromvision.domain.models.Point2D
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.sqrt

/**
 * Pure mathematical geometry and coordinate transformation engine for Carrom Vision.
 * Strictly decoupled from Android UI classes.
 */
object CoordinateMapper {

    /**
     * Converts pixel coordinates inside a rectangular board region to normalized [0.0, 1.0] coordinates.
     */
    fun pixelToNormalized(
        pixelX: Double,
        pixelY: Double,
        boardLeftPx: Double,
        boardTopPx: Double,
        boardWidthPx: Double,
        boardHeightPx: Double
    ): Point2D {
        val nx = if (boardWidthPx > 1e-6) (pixelX - boardLeftPx) / boardWidthPx else 0.0
        val ny = if (boardHeightPx > 1e-6) (pixelY - boardTopPx) / boardHeightPx else 0.0
        return Point2D(nx.coerceIn(0.0, 1.0), ny.coerceIn(0.0, 1.0))
    }

    /**
     * Converts normalized [0.0, 1.0] coordinates back into screen/canvas pixel coordinates.
     */
    fun normalizedToPixel(
        normPoint: Point2D,
        boardLeftPx: Double,
        boardTopPx: Double,
        boardWidthPx: Double,
        boardHeightPx: Double
    ): Point2D {
        return Point2D(
            x = boardLeftPx + normPoint.x * boardWidthPx,
            y = boardTopPx + normPoint.y * boardHeightPx
        )
    }

    /**
     * Calculates Euclidean distance between two normalized points.
     */
    fun calculateDistance(a: Point2D, b: Point2D): Double = a.distanceTo(b)

    /**
     * Calculates the shot angle in degrees using the required formula:
     * angle = atan2(targetY - strikerY, targetX - strikerX) converted to degrees [-180, 180].
     */
    fun calculateShotAngleDegrees(strikerPos: Point2D, targetPos: Point2D): Double {
        val radians = atan2(targetPos.y - strikerPos.y, targetPos.x - strikerPos.x)
        return Math.toDegrees(radians)
    }

    /**
     * Calculates the required Ghost-Ball center position where the Striker's center must arrive
     * at the exact instant of contact so that the Target Coin is propelled along desiredDirection.
     *
     * Mathematical Derivation:
     * Let C_coin be the target coin center, R_coin its radius, R_striker the striker radius,
     * and u_dir be the unit vector pointing from C_coin toward the target pocket (or cushion aim point).
     * At impact, the contact normal points from Ghost-Ball center C_ghost to C_coin along u_dir.
     * Therefore:
     *   C_ghost = C_coin - u_dir * (R_coin + R_striker)
     */
    fun calculateGhostBallContactPoint(
        targetCoinCenter: Point2D,
        desiredTargetMovePoint: Point2D,
        coinRadius: Double,
        strikerRadius: Double
    ): Point2D {
        val directionToPocket = (desiredTargetMovePoint - targetCoinCenter).normalized()
        val combinedRadii = coinRadius + strikerRadius
        return targetCoinCenter - (directionToPocket * combinedRadii)
    }

    /**
     * Calculates the physical surface contact point between the Striker and the Target Coin at impact:
     *   P_impact = C_coin - u_dir * R_coin
     */
    fun calculateSurfaceImpactPoint(
        targetCoinCenter: Point2D,
        desiredTargetMovePoint: Point2D,
        coinRadius: Double
    ): Point2D {
        val directionToPocket = (desiredTargetMovePoint - targetCoinCenter).normalized()
        return targetCoinCenter - (directionToPocket * coinRadius)
    }

    /**
     * Calculates the cut angle (in degrees, [0, 180]) between the Striker's incoming approach vector
     * and the Target Coin's outgoing departure vector.
     * Cut angle = 0° means a dead-straight inline shot; > 78° is physically grazing/infeasible.
     */
    fun calculateCutAngleDegrees(
        strikerPos: Point2D,
        ghostBallPos: Point2D,
        targetCoinPos: Point2D,
        desiredTargetMovePoint: Point2D
    ): Double {
        val incomingVec = (ghostBallPos - strikerPos).normalized()
        val outgoingVec = (desiredTargetMovePoint - targetCoinPos).normalized()
        val dotProd = incomingVec.dot(outgoingVec).coerceIn(-1.0, 1.0)
        return Math.toDegrees(acos(dotProd))
    }

    /**
     * Computes the minimum perpendicular distance from point P to finite line segment AB.
     */
    fun pointToSegmentDistance(p: Point2D, a: Point2D, b: Point2D): Double {
        val ab = b - a
        val lenSq = ab.dot(ab)
        if (lenSq < 1e-12) return p.distanceTo(a)
        val t = ((p - a).dot(ab) / lenSq).coerceIn(0.0, 1.0)
        val projection = a + (ab * t)
        return p.distanceTo(projection)
    }

    /**
     * Checks which other coins on the board obstruct a moving circular body of radius `movingRadius`
     * traveling along segment [start, end].
     */
    fun findObstaclesAlongSegment(
        start: Point2D,
        end: Point2D,
        movingRadius: Double,
        allObjects: List<DetectedObject>,
        excludedObjectIds: Set<String>
    ): List<DetectedObject> {
        val segLength = start.distanceTo(end)
        if (segLength < 1e-6) return emptyList()

        return allObjects.filter { candidate ->
            if (candidate.id in excludedObjectIds) {
                false
            } else {
                val clearanceThreshold = movingRadius + candidate.radius - 0.002
                val distToSegment = pointToSegmentDistance(candidate.center, start, end)
                // Also ensure obstacle lies strictly between start and end projections
                val segDir = (end - start).normalized()
                val projAlong = (candidate.center - start).dot(segDir)
                distToSegment < clearanceThreshold && projAlong > -candidate.radius && projAlong < (segLength + candidate.radius)
            }
        }
    }
}
