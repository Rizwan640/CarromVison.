package com.rizwan.carromvision.calibration

import com.google.gson.Gson
import com.rizwan.carromvision.domain.models.BoardGeometry
import com.rizwan.carromvision.domain.models.DetectedObject
import com.rizwan.carromvision.domain.models.ObjectType
import com.rizwan.carromvision.domain.models.Pocket
import com.rizwan.carromvision.domain.models.Point2D

/**
 * Local calibration profile storing manual board corners, pocket centers, and radii overrides.
 */
data class CalibrationProfile(
    val profileName: String = "Default Board Profile",
    val topLeftCornerNorm: Point2D = Point2D(0.0, 0.0),
    val topRightCornerNorm: Point2D = Point2D(1.0, 0.0),
    val bottomRightCornerNorm: Point2D = Point2D(1.0, 1.0),
    val bottomLeftCornerNorm: Point2D = Point2D(0.0, 1.0),
    val pockets: List<Pocket> = BoardGeometry.defaultPockets(),
    val coinRadiusNorm: Double = 0.029,
    val strikerRadiusNorm: Double = 0.038,
    val baselineMinY: Double = 0.78,
    val baselineMaxY: Double = 0.86
)

/**
 * Manages manual calibration of board corners, pockets, striker, and coin detections.
 */
class CalibrationManager(private val gson: Gson = Gson()) {

    private var activeProfile: CalibrationProfile = CalibrationProfile()

    fun getActiveProfile(): CalibrationProfile = activeProfile

    fun setActiveProfile(profile: CalibrationProfile) {
        activeProfile = profile
    }

    fun updateCorner(cornerIndex: Int, pointNorm: Point2D): CalibrationProfile {
        val clamped = Point2D(
            x = pointNorm.x.coerceIn(0.0, 1.0),
            y = pointNorm.y.coerceIn(0.0, 1.0)
        )
        activeProfile = when (cornerIndex) {
            0 -> activeProfile.copy(topLeftCornerNorm = clamped)
            1 -> activeProfile.copy(topRightCornerNorm = clamped)
            2 -> activeProfile.copy(bottomRightCornerNorm = clamped)
            3 -> activeProfile.copy(bottomLeftCornerNorm = clamped)
            else -> activeProfile
        }
        return activeProfile
    }

    fun updatePocketCenter(pocketId: Int, newCenterNorm: Point2D): CalibrationProfile {
        val clamped = Point2D(
            x = newCenterNorm.x.coerceIn(0.02, 0.98),
            y = newCenterNorm.y.coerceIn(0.02, 0.98)
        )
        val updatedPockets = activeProfile.pockets.map { pocket ->
            if (pocket.id == pocketId) pocket.copy(x = clamped.x, y = clamped.y) else pocket
        }
        activeProfile = activeProfile.copy(pockets = updatedPockets)
        return activeProfile
    }

    fun adjustObjectPosition(
        objects: List<DetectedObject>,
        objectId: String,
        newX: Double,
        newY: Double
    ): List<DetectedObject> {
        val clampedX = newX.coerceIn(0.03, 0.97)
        val clampedY = newY.coerceIn(0.03, 0.97)
        return objects.map { obj ->
            if (obj.id == objectId) {
                obj.copy(
                    x = clampedX,
                    y = clampedY,
                    confidence = 1.0,
                    isManuallyAdjusted = true
                )
            } else {
                obj
            }
        }
    }

    fun adjustObjectRadius(
        objects: List<DetectedObject>,
        objectId: String,
        newRadius: Double
    ): List<DetectedObject> {
        val clampedR = newRadius.coerceIn(0.015, 0.065)
        return objects.map { obj ->
            if (obj.id == objectId) {
                obj.copy(radius = clampedR, isManuallyAdjusted = true)
            } else {
                obj
            }
        }
    }

    fun reclassifyObject(
        objects: List<DetectedObject>,
        objectId: String,
        newType: ObjectType
    ): List<DetectedObject> {
        return objects.map { obj ->
            if (obj.id == objectId) {
                obj.copy(
                    type = newType,
                    confidence = 1.0,
                    isManuallyAdjusted = true
                )
            } else {
                obj
            }
        }
    }

    fun serializeProfile(profile: CalibrationProfile = activeProfile): String {
        return gson.toJson(profile)
    }

    fun deserializeProfile(json: String): CalibrationProfile {
        if (json.isBlank()) return CalibrationProfile()
        return try {
            gson.fromJson(json, CalibrationProfile::class.java) ?: CalibrationProfile()
        } catch (e: Exception) {
            CalibrationProfile()
        }
    }
}
