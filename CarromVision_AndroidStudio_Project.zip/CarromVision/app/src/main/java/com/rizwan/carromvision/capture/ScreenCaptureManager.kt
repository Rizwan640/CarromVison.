package com.rizwan.carromvision.capture

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class CaptureStatus {
    IDLE,
    PERMISSION_REQUIRED,
    READY_TO_CAPTURE,
    CAPTURING_FRAME,
    STOPPED,
    REVOKED_OR_ERROR
}

/**
 * Manages explicit user-authorized Android MediaProjection screen capture.
 * Captures single on-demand frames when requested by the user without continuous background recording.
 */
class ScreenCaptureManager(private val context: Context) {

    private val projectionManager: MediaProjectionManager? =
        context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _status = MutableStateFlow(CaptureStatus.IDLE)
    val status: StateFlow<CaptureStatus> = _status.asStateFlow()

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            super.onStop()
            releaseResources()
            _status.value = CaptureStatus.REVOKED_OR_ERROR
        }
    }

    fun createScreenCaptureIntent(): Intent? {
        _status.value = CaptureStatus.PERMISSION_REQUIRED
        return projectionManager?.createScreenCaptureIntent()
    }

    fun onPermissionGranted(resultCode: Int, data: Intent) {
        val mp = projectionManager?.getMediaProjection(resultCode, data)
        if (mp == null) {
            _status.value = CaptureStatus.REVOKED_OR_ERROR
            return
        }
        mediaProjection = mp
        mp.registerCallback(projectionCallback, mainHandler)
        _status.value = CaptureStatus.READY_TO_CAPTURE
    }

    fun onPermissionDenied() {
        releaseResources()
        _status.value = CaptureStatus.REVOKED_OR_ERROR
    }

    /**
     * Captures a single screenshot frame on explicit user action and releases the VirtualDisplay immediately.
     */
    @SuppressLint("WrongConstant")
    fun captureSingleFrame(
        screenWidth: Int,
        screenHeight: Int,
        screenDensityDpi: Int,
        onBitmapCaptured: (Bitmap?) -> Unit
    ) {
        val mp = mediaProjection
        if (mp == null) {
            _status.value = CaptureStatus.PERMISSION_REQUIRED
            onBitmapCaptured(null)
            return
        }

        _status.value = CaptureStatus.CAPTURING_FRAME
        val targetWidth = screenWidth.coerceAtMost(1080)
        val targetHeight = screenHeight.coerceAtMost(2400)

        val reader = ImageReader.newInstance(targetWidth, targetHeight, PixelFormat.RGBA_8888, 2)
        imageReader = reader

        val vDisplay = mp.createVirtualDisplay(
            "CarromVisionSingleFrame",
            targetWidth,
            targetHeight,
            screenDensityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            mainHandler
        )
        virtualDisplay = vDisplay

        reader.setOnImageAvailableListener({ availableReader ->
            val image = try {
                availableReader.acquireLatestImage()
            } catch (e: Exception) {
                null
            }
            if (image != null) {
                try {
                    val planes = image.planes
                    val buffer = planes[0].buffer
                    val pixelStride = planes[0].pixelStride
                    val rowStride = planes[0].rowStride
                    val rowPadding = rowStride - pixelStride * targetWidth

                    val paddedBitmap = Bitmap.createBitmap(
                        targetWidth + rowPadding / pixelStride,
                        targetHeight,
                        Bitmap.Config.ARGB_8888
                    )
                    paddedBitmap.copyPixelsFromBuffer(buffer)
                    val cropped = Bitmap.createBitmap(paddedBitmap, 0, 0, targetWidth, targetHeight)
                    if (cropped != paddedBitmap) {
                        paddedBitmap.recycle()
                    }
                    onBitmapCaptured(cropped)
                } finally {
                    image.close()
                    reader.setOnImageAvailableListener(null, null)
                    vDisplay?.release()
                    virtualDisplay = null
                    reader.close()
                    imageReader = null
                    _status.value = CaptureStatus.READY_TO_CAPTURE
                }
            }
        }, mainHandler)
    }

    fun stopSession() {
        releaseResources()
        _status.value = CaptureStatus.STOPPED
    }

    private fun releaseResources() {
        try {
            virtualDisplay?.release()
        } catch (_: Exception) {}
        virtualDisplay = null

        try {
            imageReader?.close()
        } catch (_: Exception) {}
        imageReader = null

        try {
            mediaProjection?.unregisterCallback(projectionCallback)
            mediaProjection?.stop()
        } catch (_: Exception) {}
        mediaProjection = null
    }
}
