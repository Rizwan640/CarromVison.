package com.rizwan.carromvision.core.vision

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import com.rizwan.carromvision.domain.models.BoardGeometry
import com.rizwan.carromvision.domain.models.Point2D
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc

/**
 * Performs homography / perspective warping to transform the detected Carrom board quadrilateral
 * into a flat, top-down square bitmap corresponding to normalized coordinates [0.0, 1.0].
 */
class PerspectiveTransformer {

    fun warpBoardToNormalizedSquare(
        sourceBitmap: Bitmap,
        boardGeometry: BoardGeometry,
        outputSizePx: Int = 640
    ): Bitmap {
        return try {
            warpWithOpenCv(sourceBitmap, boardGeometry, outputSizePx)
        } catch (_: Throwable) {
            warpWithAndroidMatrix(sourceBitmap, boardGeometry, outputSizePx)
        }
    }

    private fun warpWithOpenCv(
        sourceBitmap: Bitmap,
        boardGeometry: BoardGeometry,
        outputSizePx: Int
    ): Bitmap {
        val srcMat = Mat(sourceBitmap.height, sourceBitmap.width, CvType.CV_8UC4)
        Utils.bitmapToMat(sourceBitmap, srcMat)

        val srcPoints = MatOfPoint2f(
            Point(boardGeometry.topLeftPx.x, boardGeometry.topLeftPx.y),
            Point(boardGeometry.topRightPx.x, boardGeometry.topRightPx.y),
            Point(boardGeometry.bottomRightPx.x, boardGeometry.bottomRightPx.y),
            Point(boardGeometry.bottomLeftPx.x, boardGeometry.bottomLeftPx.y)
        )

        val dstPoints = MatOfPoint2f(
            Point(0.0, 0.0),
            Point(outputSizePx.toDouble(), 0.0),
            Point(outputSizePx.toDouble(), outputSizePx.toDouble()),
            Point(0.0, outputSizePx.toDouble())
        )

        val transformMatrix = Imgproc.getPerspectiveTransform(srcPoints, dstPoints)
        val warpedMat = Mat(outputSizePx, outputSizePx, CvType.CV_8UC4)
        Imgproc.warpPerspective(
            srcMat,
            warpedMat,
            transformMatrix,
            Size(outputSizePx.toDouble(), outputSizePx.toDouble())
        )

        val outputBitmap = Bitmap.createBitmap(outputSizePx, outputSizePx, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(warpedMat, outputBitmap)

        srcMat.release()
        srcPoints.release()
        dstPoints.release()
        transformMatrix.release()
        warpedMat.release()

        return outputBitmap
    }

    private fun warpWithAndroidMatrix(
        sourceBitmap: Bitmap,
        boardGeometry: BoardGeometry,
        outputSizePx: Int
    ): Bitmap {
        val outputBitmap = Bitmap.createBitmap(outputSizePx, outputSizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outputBitmap)
        val matrix = Matrix()

        val src = floatArrayOf(
            boardGeometry.topLeftPx.x.toFloat(), boardGeometry.topLeftPx.y.toFloat(),
            boardGeometry.topRightPx.x.toFloat(), boardGeometry.topRightPx.y.toFloat(),
            boardGeometry.bottomRightPx.x.toFloat(), boardGeometry.bottomRightPx.y.toFloat(),
            boardGeometry.bottomLeftPx.x.toFloat(), boardGeometry.bottomLeftPx.y.toFloat()
        )
        val dst = floatArrayOf(
            0f, 0f,
            outputSizePx.toFloat(), 0f,
            outputSizePx.toFloat(), outputSizePx.toFloat(),
            0f, outputSizePx.toFloat()
        )

        matrix.setPolyToPoly(src, 0, dst, 0, 4)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(sourceBitmap, matrix, paint)
        return outputBitmap
    }

    /**
     * Pure mathematical 3x3 homography transformation mapping an arbitrary quadrilateral
     * to normalized [0.0, 1.0] x [0.0, 1.0] coordinates.
     */
    fun mapBoardPixelToNormalized(
        pixelPoint: Point2D,
        boardGeometry: BoardGeometry
    ): Point2D {
        val tl = boardGeometry.topLeftPx
        val tr = boardGeometry.topRightPx
        val br = boardGeometry.bottomRightPx
        val bl = boardGeometry.bottomLeftPx

        val topWidth = tr.distanceTo(tl).coerceAtLeast(1e-6)
        val leftHeight = bl.distanceTo(tl).coerceAtLeast(1e-6)

        val topVec = (tr - tl).normalized()
        val leftVec = (bl - tl).normalized()
        val rel = pixelPoint - tl

        val u = (rel.dot(topVec) / topWidth).coerceIn(0.0, 1.0)
        val v = (rel.dot(leftVec) / leftHeight).coerceIn(0.0, 1.0)
        return Point2D(u, v)
    }

    fun mapNormalizedToBoardPixel(
        normPoint: Point2D,
        boardGeometry: BoardGeometry
    ): Point2D {
        val u = normPoint.x.coerceIn(0.0, 1.0)
        val v = normPoint.y.coerceIn(0.0, 1.0)

        // Bilinear interpolation across quadrilateral corners
        val top = boardGeometry.topLeftPx * (1.0 - u) + boardGeometry.topRightPx * u
        val bottom = boardGeometry.bottomLeftPx * (1.0 - u) + boardGeometry.bottomRightPx * u
        return top * (1.0 - v) + bottom * v
    }
}
