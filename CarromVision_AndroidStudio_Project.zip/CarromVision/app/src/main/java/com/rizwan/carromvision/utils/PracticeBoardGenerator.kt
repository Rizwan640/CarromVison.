package com.rizwan.carromvision.utils

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF

/**
 * Generates realistic synthetic Carrom board bitmaps for Practice Mode and on-device testing
 * when the user enters Practice Mode without importing an external screenshot.
 */
object PracticeBoardGenerator {

    fun createPracticeBitmap(width: Int = 800, height: Int = 800, presetIndex: Int = 0): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Outer wooden frame
        val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(42, 26, 18)
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), framePaint)

        // Playing surface (warm wood)
        val margin = width * 0.06f
        val boardRect = RectF(margin, margin, width - margin, height - margin)
        val surfacePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(228, 196, 148)
            style = Paint.Style.FILL
        }
        canvas.drawRect(boardRect, surfacePaint)

        val boardSize = boardRect.width()

        // Four corner pockets (dark circular wells)
        val pocketRadius = boardSize * 0.042f
        val pocketOffset = boardSize * 0.055f
        val pocketPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(18, 18, 20)
            style = Paint.Style.FILL
        }
        val pockets = listOf(
            Pair(boardRect.left + pocketOffset, boardRect.top + pocketOffset),
            Pair(boardRect.right - pocketOffset, boardRect.top + pocketOffset),
            Pair(boardRect.right - pocketOffset, boardRect.bottom - pocketOffset),
            Pair(boardRect.left + pocketOffset, boardRect.bottom - pocketOffset)
        )
        for ((px, py) in pockets) {
            canvas.drawCircle(px, py, pocketRadius, pocketPaint)
        }

        // Center circle & baselines (subtle markings)
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(120, 80, 50)
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
        }
        canvas.drawCircle(width / 2f, height / 2f, boardSize * 0.11f, linePaint)

        val coinRadius = boardSize * 0.029f
        val strikerRadius = boardSize * 0.038f

        fun normToPx(nx: Float, ny: Float): Pair<Float, Float> {
            return Pair(
                boardRect.left + nx * boardSize,
                boardRect.top + ny * boardSize
            )
        }

        // Draw Red Queen
        val queenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(210, 32, 42)
            style = Paint.Style.FILL
        }
        val (qx, qy) = if (presetIndex % 2 == 0) normToPx(0.50f, 0.46f) else normToPx(0.38f, 0.34f)
        canvas.drawCircle(qx, qy, coinRadius, queenPaint)

        // Draw White Coins
        val whitePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(245, 242, 232)
            style = Paint.Style.FILL
        }
        val whitePositions = if (presetIndex % 2 == 0) {
            listOf(
                Pair(0.28f, 0.30f),
                Pair(0.68f, 0.32f),
                Pair(0.42f, 0.58f),
                Pair(0.75f, 0.52f)
            )
        } else {
            listOf(
                Pair(0.22f, 0.24f),
                Pair(0.62f, 0.44f),
                Pair(0.54f, 0.64f)
            )
        }
        for ((wx, wy) in whitePositions) {
            val (cx, cy) = normToPx(wx, wy)
            canvas.drawCircle(cx, cy, coinRadius, whitePaint)
        }

        // Draw Black Coins
        val blackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(36, 38, 44)
            style = Paint.Style.FILL
        }
        val blackPositions = if (presetIndex % 2 == 0) {
            listOf(
                Pair(0.34f, 0.44f),
                Pair(0.60f, 0.38f),
                Pair(0.56f, 0.65f)
            )
        } else {
            listOf(
                Pair(0.46f, 0.28f),
                Pair(0.72f, 0.36f),
                Pair(0.32f, 0.60f)
            )
        }
        for ((bx, by) in blackPositions) {
            val (cx, cy) = normToPx(bx, by)
            canvas.drawCircle(cx, cy, coinRadius, blackPaint)
        }

        // Draw Striker on bottom baseline (distinctive cyan-gold ring & larger radius)
        val strikerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(35, 195, 215)
            style = Paint.Style.FILL
        }
        val strikerPos = if (presetIndex % 2 == 0) normToPx(0.48f, 0.82f) else normToPx(0.60f, 0.82f)
        canvas.drawCircle(strikerPos.first, strikerPos.second, strikerRadius, strikerPaint)

        return bitmap
    }
}
