package com.rizwan.carromvision.core.physics

import com.rizwan.carromvision.domain.models.PhysicsConfig
import com.rizwan.carromvision.domain.models.Point2D
import com.rizwan.carromvision.domain.models.TrajectorySegment
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Simulates forward multi-segment trajectories with sliding friction deceleration
 * and cushion rebounds for post-collision Striker and Coin movement paths.
 */
class TrajectoryEngine {

    /**
     * Simulates the post-collision path of a circular body (e.g. Striker after hitting Target Coin),
     * folding in up to `maxBounces` cushion reflections until friction brings the body to rest.
     */
    fun traceDeceleratingTrajectory(
        startPos: Point2D,
        initialVelocity: Point2D,
        objectRadius: Double,
        config: PhysicsConfig,
        maxBounces: Int = 2
    ): Pair<List<TrajectorySegment>, Point2D> {
        val speed = sqrt(initialVelocity.dot(initialVelocity))
        if (speed < 0.04) {
            return Pair(emptyList(), startPos)
        }

        val muEff = (config.frictionCoefficient * 1.35).coerceAtLeast(0.05)
        var remainingDistance = ((speed * speed) / (2.0 * muEff)).coerceIn(0.05, 1.35)
        var currentPos = startPos
        var currentDir = initialVelocity.normalized()

        val minB = objectRadius.coerceIn(0.025, 0.055)
        val maxB = 1.0 - minB
        val segments = ArrayList<TrajectorySegment>()
        var bounces = 0

        while (remainingDistance > 0.015 && bounces <= maxBounces) {
            val hit = findNextWallHit(currentPos, currentDir, minB, maxB)
            if (hit == null || hit.first >= remainingDistance) {
                val finalPos = Point2D(
                    x = (currentPos.x + currentDir.x * remainingDistance).coerceIn(minB, maxB),
                    y = (currentPos.y + currentDir.y * remainingDistance).coerceIn(minB, maxB)
                )
                segments.add(
                    TrajectorySegment(
                        start = currentPos,
                        end = finalPos,
                        isCushionRebound = bounces > 0
                    )
                )
                currentPos = finalPos
                break
            } else {
                val distToWall = hit.first
                val wall = hit.second
                val hitPoint = Point2D(
                    x = (currentPos.x + currentDir.x * distToWall).coerceIn(minB, maxB),
                    y = (currentPos.y + currentDir.y * distToWall).coerceIn(minB, maxB)
                )
                segments.add(
                    TrajectorySegment(
                        start = currentPos,
                        end = hitPoint,
                        isCushionRebound = bounces > 0,
                        cushionIndex = wall.index
                    )
                )
                remainingDistance = (remainingDistance - distToWall) * config.restitutionCushion
                currentPos = hitPoint
                currentDir = when (wall) {
                    CushionWall.LEFT, CushionWall.RIGHT -> Point2D(-currentDir.x, currentDir.y * 0.94).normalized()
                    CushionWall.TOP, CushionWall.BOTTOM -> Point2D(currentDir.x * 0.94, -currentDir.y).normalized()
                }
                bounces++
            }
        }

        return Pair(segments, currentPos)
    }

    private fun findNextWallHit(
        pos: Point2D,
        dir: Point2D,
        minB: Double,
        maxB: Double
    ): Pair<Double, CushionWall>? {
        var bestDist = Double.MAX_VALUE
        var bestWall: CushionWall? = null

        if (dir.x < -1e-6) {
            val d = (minB - pos.x) / dir.x
            if (d > 1e-4 && d < bestDist) {
                bestDist = d
                bestWall = CushionWall.LEFT
            }
        } else if (dir.x > 1e-6) {
            val d = (maxB - pos.x) / dir.x
            if (d > 1e-4 && d < bestDist) {
                bestDist = d
                bestWall = CushionWall.RIGHT
            }
        }

        if (dir.y < -1e-6) {
            val d = (minB - pos.y) / dir.y
            if (d > 1e-4 && d < bestDist) {
                bestDist = d
                bestWall = CushionWall.TOP
            }
        } else if (dir.y > 1e-6) {
            val d = (maxB - pos.y) / dir.y
            if (d > 1e-4 && d < bestDist) {
                bestDist = d
                bestWall = CushionWall.BOTTOM
            }
        }

        return if (bestWall != null && bestDist < 10.0) Pair(bestDist, bestWall) else null
    }
}
