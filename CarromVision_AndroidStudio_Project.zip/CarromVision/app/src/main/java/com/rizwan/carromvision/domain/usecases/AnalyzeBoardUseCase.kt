package com.rizwan.carromvision.domain.usecases

import android.graphics.Bitmap
import com.rizwan.carromvision.calibration.CalibrationProfile
import com.rizwan.carromvision.core.vision.BoardDetector
import com.rizwan.carromvision.core.vision.CoinDetector
import com.rizwan.carromvision.core.vision.PerspectiveTransformer
import com.rizwan.carromvision.core.vision.PocketDetector
import com.rizwan.carromvision.core.vision.StrikerDetector
import com.rizwan.carromvision.domain.algorithms.ShotAnalyzer
import com.rizwan.carromvision.domain.models.BoardGeometry
import com.rizwan.carromvision.domain.models.DetectedObject
import com.rizwan.carromvision.domain.models.PhysicsConfig
import com.rizwan.carromvision.domain.models.ShotSuggestion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class FullAnalysisPipelineResult(
    val normalizedBoardBitmap: Bitmap,
    val boardGeometry: BoardGeometry,
    val detectedObjects: List<DetectedObject>,
    val shotSuggestions: List<ShotSuggestion>,
    val requiresUserConfirmation: Boolean,
    val statusMessage: String
)

/**
 * Orchestrates the complete on-device Computer Vision + Mathematical Shot Analysis pipeline.
 */
class AnalyzeBoardUseCase(
    private val boardDetector: BoardDetector = BoardDetector(),
    private val perspectiveTransformer: PerspectiveTransformer = PerspectiveTransformer(),
    private val pocketDetector: PocketDetector = PocketDetector(),
    private val coinDetector: CoinDetector = CoinDetector(),
    private val strikerDetector: StrikerDetector = StrikerDetector(),
    private val shotAnalyzer: ShotAnalyzer = ShotAnalyzer()
) {

    suspend fun execute(
        sourceBitmap: Bitmap,
        physicsConfig: PhysicsConfig,
        calibrationProfile: CalibrationProfile,
        selectedTargetId: String? = null,
        selectedPocketId: Int? = null
    ): FullAnalysisPipelineResult = withContext(Dispatchers.Default) {
        // 1. Detect board boundaries in pixel space
        val rawBoard = boardDetector.detectBoard(sourceBitmap, physicsConfig)

        // 2. Perspective-transform board into a normalized square bitmap
        val targetSquareSize = if (physicsConfig.cpuFriendlyMode) 640 else 800
        val warpedBitmap = perspectiveTransformer.warpBoardToNormalizedSquare(
            sourceBitmap = sourceBitmap,
            boardGeometry = rawBoard,
            outputSizePx = targetSquareSize
        )

        // 3. Detect four corner pockets in normalized coordinates
        val detectedPockets = pocketDetector.detectPockets(warpedBitmap, calibrationProfile)
        val boardGeometry = rawBoard.copy(pockets = detectedPockets)

        // 4. Detect White Coins, Black Coins, and Red Queen
        val coins = coinDetector.detectCoins(warpedBitmap, physicsConfig)

        // 5. Detect Striker
        val striker = strikerDetector.detectStriker(warpedBitmap, coins, physicsConfig)

        val allObjects = buildList {
            addAll(coins)
            if (striker != null) add(striker)
        }

        // 6. Validate detection confidence
        val lowConfidenceObjects = allObjects.count { it.confidence < physicsConfig.detectionSensitivity }
        val requiresConfirmation = striker == null || allObjects.isEmpty() || lowConfidenceObjects > 2

        // 7. Run Shot Analysis Engine using actual detected coordinates
        val shots = shotAnalyzer.analyzeAllShots(
            boardGeometry = boardGeometry,
            detectedObjects = allObjects,
            physicsConfig = physicsConfig,
            selectedTargetId = selectedTargetId,
            selectedPocketId = selectedPocketId
        )

        val statusMsg = when {
            allObjects.isEmpty() -> "No coins detected. Please use Manual Adjustment or check lighting."
            striker == null -> "Coins detected (${coins.size}), striker uncertain. Tap Manual Adjustment to place striker."
            requiresConfirmation -> "Detected ${coins.size} coins & striker. Some objects have moderate confidence—verify positions."
            else -> "Detected ${coins.size} coins, striker, and 4 pockets (${shots.size} viable shots calculated)."
        }

        FullAnalysisPipelineResult(
            normalizedBoardBitmap = warpedBitmap,
            boardGeometry = boardGeometry,
            detectedObjects = allObjects,
            shotSuggestions = shots,
            requiresUserConfirmation = requiresConfirmation,
            statusMessage = statusMsg
        )
    }

    suspend fun recalculateFromObjects(
        normalizedBoardBitmap: Bitmap,
        boardGeometry: BoardGeometry,
        detectedObjects: List<DetectedObject>,
        physicsConfig: PhysicsConfig,
        selectedTargetId: String? = null,
        selectedPocketId: Int? = null
    ): List<ShotSuggestion> = withContext(Dispatchers.Default) {
        shotAnalyzer.analyzeAllShots(
            boardGeometry = boardGeometry,
            detectedObjects = detectedObjects,
            physicsConfig = physicsConfig,
            selectedTargetId = selectedTargetId,
            selectedPocketId = selectedPocketId
        )
    }
}
