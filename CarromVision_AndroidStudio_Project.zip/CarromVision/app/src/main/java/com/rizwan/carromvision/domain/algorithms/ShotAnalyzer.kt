package com.rizwan.carromvision.domain.algorithms

import com.rizwan.carromvision.core.geometry.CoordinateMapper
import com.rizwan.carromvision.core.physics.CollisionEngine
import com.rizwan.carromvision.core.physics.CushionReflectionEngine
import com.rizwan.carromvision.core.physics.TrajectoryEngine
import com.rizwan.carromvision.domain.models.BoardGeometry
import com.rizwan.carromvision.domain.models.DetectedObject
import com.rizwan.carromvision.domain.models.ObjectType
import com.rizwan.carromvision.domain.models.PhysicsConfig
import com.rizwan.carromvision.domain.models.Pocket
import com.rizwan.carromvision.domain.models.Point2D
import com.rizwan.carromvision.domain.models.ShotSuggestion
import com.rizwan.carromvision.domain.models.ShotType
import com.rizwan.carromvision.domain.models.TrajectorySegment

/**
 * Independent Shot Analysis Engine implementing the 13-step shot evaluation pipeline:
 * Evaluates direct shots, single-cushion bank shots, and double-cushion bank shots for all
 * detected coins (or user-selected target coin & pocket), checks obstacle clearance,
 * estimates post-collision striker trajectories, and returns ranked options.
 */
class ShotAnalyzer(
    private val collisionEngine: CollisionEngine = CollisionEngine(),
    private val cushionReflectionEngine: CushionReflectionEngine = CushionReflectionEngine(),
    private val trajectoryEngine: TrajectoryEngine = TrajectoryEngine(),
    private val rankingEngine: ShotRankingEngine = ShotRankingEngine()
) {

    fun analyzeAllShots(
        boardGeometry: BoardGeometry,
        detectedObjects: List<DetectedObject>,
        physicsConfig: PhysicsConfig,
        selectedTargetId: String? = null,
        selectedPocketId: Int? = null
    ): List<ShotSuggestion> {
        val coins = detectedObjects.filter { it.type != ObjectType.STRIKER && it.type != ObjectType.POCKET }
        if (coins.isEmpty()) return emptyList()

        val striker = detectedObjects.firstOrNull { it.type == ObjectType.STRIKER }
        val strikerPos = striker?.center ?: Point2D(0.50, 0.82)
        val strikerRadius = striker?.radius ?: physicsConfig.defaultStrikerRadius
        val strikerId = striker?.id ?: "striker_default"

        val targetCoins = if (selectedTargetId != null) {
            coins.filter { it.id == selectedTargetId }.ifEmpty { coins }
        } else {
            coins
        }

        val targetPockets = if (selectedPocketId != null) {
            boardGeometry.pockets.filter { it.id == selectedPocketId }.ifEmpty { boardGeometry.pockets }
        } else {
            boardGeometry.pockets
        }

        val pocketCenters = boardGeometry.pockets.map { it.center }
        val candidates = ArrayList<ShotSuggestion>()
        var suggestionSeq = 1

        for (coin in targetCoins) {
            val excludedIds = setOf(coin.id, strikerId)

            for (pocket in targetPockets) {
                // 1. Evaluate Direct Shot (Coin -> Pocket)
                val directGhost = CoordinateMapper.calculateGhostBallContactPoint(
                    targetCoinCenter = coin.center,
                    desiredTargetMovePoint = pocket.center,
                    coinRadius = coin.radius,
                    strikerRadius = strikerRadius
                )

                if (isPointInsidePlayableBoard(directGhost, strikerRadius)) {
                    val cutAngle = CoordinateMapper.calculateCutAngleDegrees(
                        strikerPos = strikerPos,
                        ghostBallPos = directGhost,
                        targetCoinPos = coin.center,
                        desiredTargetMovePoint = pocket.center
                    )

                    if (cutAngle <= 76.0) {
                        val strikerObstacles = CoordinateMapper.findObstaclesAlongSegment(
                            start = strikerPos,
                            end = directGhost,
                            movingRadius = strikerRadius,
                            allObjects = detectedObjects,
                            excludedObjectIds = excludedIds
                        )
                        val coinObstacles = CoordinateMapper.findObstaclesAlongSegment(
                            start = coin.center,
                            end = pocket.center,
                            movingRadius = coin.radius,
                            allObjects = detectedObjects,
                            excludedObjectIds = excludedIds
                        )
                        val allObstacles = (strikerObstacles + coinObstacles).distinctBy { it.id }

                        val collisionPred = collisionEngine.predictCollision(
                            strikerStartPos = strikerPos,
                            ghostBallPos = directGhost,
                            targetCoinCenter = coin.center,
                            desiredTargetMovePoint = pocket.center,
                            coinRadius = coin.radius,
                            strikerRadius = strikerRadius,
                            config = physicsConfig
                        )

                        val (postStrikerSegments, finalStrikerPos) = trajectoryEngine.traceDeceleratingTrajectory(
                            startPos = directGhost,
                            initialVelocity = collisionPred.strikerPostVelocity,
                            objectRadius = strikerRadius,
                            config = physicsConfig,
                            maxBounces = 1
                        )

                        val strikerDist = strikerPos.distanceTo(directGhost)
                        val coinDist = coin.center.distanceTo(pocket.center)
                        val shotAngleDeg = CoordinateMapper.calculateShotAngleDegrees(strikerPos, directGhost)

                        val confidence = rankingEngine.calculateConfidenceScore(
                            shotType = ShotType.DIRECT_SHOT,
                            targetCoin = coin,
                            cutAngleDeg = cutAngle,
                            strikerToContactDist = strikerDist,
                            coinTotalTravelDist = coinDist,
                            cushionCount = 0,
                            obstacleCount = allObstacles.size,
                            strikerFinalPos = finalStrikerPos,
                            pocketPositions = pocketCenters
                        )

                        val isUncertain = confidence < 0.58 || cutAngle > 58.0 || allObstacles.isNotEmpty()

                        candidates.add(
                            ShotSuggestion(
                                id = "shot_${suggestionSeq++}",
                                shotType = ShotType.DIRECT_SHOT,
                                targetCoin = coin,
                                targetPocket = pocket,
                                strikerStartPos = strikerPos,
                                requiredContactPoint = directGhost,
                                requiredAngleDegrees = shotAngleDeg,
                                cutAngleDegrees = cutAngle,
                                strikerPath = listOf(TrajectorySegment(strikerPos, directGhost)),
                                coinPath = listOf(TrajectorySegment(coin.center, pocket.center)),
                                strikerPostCollisionPath = postStrikerSegments,
                                collisionPrediction = collisionPred.copy(estimatedStrikerFinalPos = finalStrikerPos),
                                obstaclesOnPath = allObstacles,
                                cushionCount = 0,
                                estimatedStrikerFinalPos = finalStrikerPos,
                                confidenceScore = confidence,
                                isUncertain = isUncertain,
                                summaryNote = if (allObstacles.isEmpty()) {
                                    "Clear direct shot to ${pocket.name} (${"%.1f".format(cutAngle)}° cut)"
                                } else {
                                    "Direct path partially obstructed by ${allObstacles.size} coin(s)"
                                }
                            )
                        )
                    }
                }

                // 2. Evaluate Single-Cushion Bank Shots for Target Coin -> Cushion -> Pocket
                val singleBankPaths = cushionReflectionEngine.calculateSingleCushionPaths(
                    startPoint = coin.center,
                    targetPocket = pocket,
                    objectRadius = coin.radius,
                    config = physicsConfig
                )

                for (bankPath in singleBankPaths) {
                    val bankGhost = CoordinateMapper.calculateGhostBallContactPoint(
                        targetCoinCenter = coin.center,
                        desiredTargetMovePoint = bankPath.firstBouncePoint,
                        coinRadius = coin.radius,
                        strikerRadius = strikerRadius
                    )
                    if (!isPointInsidePlayableBoard(bankGhost, strikerRadius)) continue

                    val cutAngle = CoordinateMapper.calculateCutAngleDegrees(
                        strikerPos = strikerPos,
                        ghostBallPos = bankGhost,
                        targetCoinPos = coin.center,
                        desiredTargetMovePoint = bankPath.firstBouncePoint
                    )
                    if (cutAngle > 68.0) continue

                    val strikerObstacles = CoordinateMapper.findObstaclesAlongSegment(
                        start = strikerPos,
                        end = bankGhost,
                        movingRadius = strikerRadius,
                        allObjects = detectedObjects,
                        excludedObjectIds = excludedIds
                    )
                    val segObstacles = bankPath.segments.flatMap { seg ->
                        CoordinateMapper.findObstaclesAlongSegment(
                            start = seg.start,
                            end = seg.end,
                            movingRadius = coin.radius,
                            allObjects = detectedObjects,
                            excludedObjectIds = excludedIds
                        )
                    }
                    val allObstacles = (strikerObstacles + segObstacles).distinctBy { it.id }

                    val collisionPred = collisionEngine.predictCollision(
                        strikerStartPos = strikerPos,
                        ghostBallPos = bankGhost,
                        targetCoinCenter = coin.center,
                        desiredTargetMovePoint = bankPath.firstBouncePoint,
                        coinRadius = coin.radius,
                        strikerRadius = strikerRadius,
                        config = physicsConfig
                    )

                    val (postStrikerSegments, finalStrikerPos) = trajectoryEngine.traceDeceleratingTrajectory(
                        startPos = bankGhost,
                        initialVelocity = collisionPred.strikerPostVelocity,
                        objectRadius = strikerRadius,
                        config = physicsConfig,
                        maxBounces = 1
                    )

                    val shotAngleDeg = CoordinateMapper.calculateShotAngleDegrees(strikerPos, bankGhost)
                    val confidence = rankingEngine.calculateConfidenceScore(
                        shotType = ShotType.SINGLE_BANK_SHOT,
                        targetCoin = coin,
                        cutAngleDeg = cutAngle,
                        strikerToContactDist = strikerPos.distanceTo(bankGhost),
                        coinTotalTravelDist = bankPath.totalPathLength,
                        cushionCount = 1,
                        obstacleCount = allObstacles.size,
                        strikerFinalPos = finalStrikerPos,
                        pocketPositions = pocketCenters
                    )

                    candidates.add(
                        ShotSuggestion(
                            id = "shot_${suggestionSeq++}",
                            shotType = ShotType.SINGLE_BANK_SHOT,
                            targetCoin = coin,
                            targetPocket = pocket,
                            strikerStartPos = strikerPos,
                            requiredContactPoint = bankGhost,
                            requiredAngleDegrees = shotAngleDeg,
                            cutAngleDegrees = cutAngle,
                            strikerPath = listOf(TrajectorySegment(strikerPos, bankGhost)),
                            coinPath = bankPath.segments,
                            strikerPostCollisionPath = postStrikerSegments,
                            collisionPrediction = collisionPred.copy(estimatedStrikerFinalPos = finalStrikerPos),
                            obstaclesOnPath = allObstacles,
                            cushionCount = 1,
                            estimatedStrikerFinalPos = finalStrikerPos,
                            confidenceScore = confidence,
                            isUncertain = confidence < 0.55 || allObstacles.isNotEmpty(),
                            summaryNote = "1-cushion bank via ${bankPath.cushionSequence.first().label} to ${pocket.name}"
                        )
                    )
                }

                // 3. Evaluate Double-Cushion Bank Shots when user selects a specific coin or direct paths are blocked
                if (selectedTargetId != null || targetCoins.size <= 4) {
                    val doubleBankPaths = cushionReflectionEngine.calculateDoubleCushionPaths(
                        startPoint = coin.center,
                        targetPocket = pocket,
                        objectRadius = coin.radius,
                        config = physicsConfig
                    )
                    for (dblPath in doubleBankPaths.take(2)) {
                        val dblGhost = CoordinateMapper.calculateGhostBallContactPoint(
                            targetCoinCenter = coin.center,
                            desiredTargetMovePoint = dblPath.firstBouncePoint,
                            coinRadius = coin.radius,
                            strikerRadius = strikerRadius
                        )
                        if (!isPointInsidePlayableBoard(dblGhost, strikerRadius)) continue

                        val cutAngle = CoordinateMapper.calculateCutAngleDegrees(
                            strikerPos = strikerPos,
                            ghostBallPos = dblGhost,
                            targetCoinPos = coin.center,
                            desiredTargetMovePoint = dblPath.firstBouncePoint
                        )
                        if (cutAngle > 58.0) continue

                        val strikerObstacles = CoordinateMapper.findObstaclesAlongSegment(
                            start = strikerPos,
                            end = dblGhost,
                            movingRadius = strikerRadius,
                            allObjects = detectedObjects,
                            excludedObjectIds = excludedIds
                        )
                        val segObstacles = dblPath.segments.flatMap { seg ->
                            CoordinateMapper.findObstaclesAlongSegment(
                                start = seg.start,
                                end = seg.end,
                                movingRadius = coin.radius,
                                allObjects = detectedObjects,
                                excludedObjectIds = excludedIds
                            )
                        }
                        val allObstacles = (strikerObstacles + segObstacles).distinctBy { it.id }
                        if (allObstacles.isNotEmpty()) continue

                        val collisionPred = collisionEngine.predictCollision(
                            strikerStartPos = strikerPos,
                            ghostBallPos = dblGhost,
                            targetCoinCenter = coin.center,
                            desiredTargetMovePoint = dblPath.firstBouncePoint,
                            coinRadius = coin.radius,
                            strikerRadius = strikerRadius,
                            config = physicsConfig
                        )

                        val (postStrikerSegments, finalStrikerPos) = trajectoryEngine.traceDeceleratingTrajectory(
                            startPos = dblGhost,
                            initialVelocity = collisionPred.strikerPostVelocity,
                            objectRadius = strikerRadius,
                            config = physicsConfig,
                            maxBounces = 1
                        )

                        val shotAngleDeg = CoordinateMapper.calculateShotAngleDegrees(strikerPos, dblGhost)
                        val confidence = rankingEngine.calculateConfidenceScore(
                            shotType = ShotType.DOUBLE_BANK_SHOT,
                            targetCoin = coin,
                            cutAngleDeg = cutAngle,
                            strikerToContactDist = strikerPos.distanceTo(dblGhost),
                            coinTotalTravelDist = dblPath.totalPathLength,
                            cushionCount = 2,
                            obstacleCount = 0,
                            strikerFinalPos = finalStrikerPos,
                            pocketPositions = pocketCenters
                        )

                        candidates.add(
                            ShotSuggestion(
                                id = "shot_${suggestionSeq++}",
                                shotType = ShotType.DOUBLE_BANK_SHOT,
                                targetCoin = coin,
                                targetPocket = pocket,
                                strikerStartPos = strikerPos,
                                requiredContactPoint = dblGhost,
                                requiredAngleDegrees = shotAngleDeg,
                                cutAngleDegrees = cutAngle,
                                strikerPath = listOf(TrajectorySegment(strikerPos, dblGhost)),
                                coinPath = dblPath.segments,
                                strikerPostCollisionPath = postStrikerSegments,
                                collisionPrediction = collisionPred.copy(estimatedStrikerFinalPos = finalStrikerPos),
                                obstaclesOnPath = emptyList(),
                                cushionCount = 2,
                                estimatedStrikerFinalPos = finalStrikerPos,
                                confidenceScore = confidence,
                                isUncertain = true,
                                summaryNote = "2-cushion bank (${dblPath.cushionSequence[0].label} → ${dblPath.cushionSequence[1].label})"
                            )
                        )
                    }
                }
            }
        }

        return rankingEngine.rankSuggestions(candidates).take(16)
    }

    private fun isPointInsidePlayableBoard(point: Point2D, radius: Double): Boolean {
        val margin = radius.coerceAtLeast(0.032)
        return point.x in margin..(1.0 - margin) && point.y in margin..(1.0 - margin)
    }
}
