package com.rizwan.carromvision.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val CharcoalBackground = Color(0xFF121316)
val CharcoalSurface = Color(0xFF1B1D22)
val CharcoalCard = Color(0xFF23262E)
val SubtleGold = Color(0xFFD4AF37)
val SubtleCrimson = Color(0xFFD9383A)
val TextPrimary = Color(0xFFF4F5F7)
val TextSecondary = Color(0xFFA6AAB4)
val DirectShotGreen = Color(0xFF4CAF50)
val BankShotAmber = Color(0xFFFFB300)
val CollisionCyan = Color(0xFF26C6DA)
val UncertainMutedRed = Color(0xFFE57373)

private val GoldDarkColorScheme = darkColorScheme(
    primary = SubtleGold,
    onPrimary = Color(0xFF121316),
    secondary = SubtleCrimson,
    onSecondary = TextPrimary,
    background = CharcoalBackground,
    onBackground = TextPrimary,
    surface = CharcoalSurface,
    onSurface = TextPrimary,
    surfaceVariant = CharcoalCard,
    onSurfaceVariant = TextSecondary
)

private val CrimsonDarkColorScheme = darkColorScheme(
    primary = SubtleCrimson,
    onPrimary = TextPrimary,
    secondary = SubtleGold,
    onSecondary = Color(0xFF121316),
    background = CharcoalBackground,
    onBackground = TextPrimary,
    surface = CharcoalSurface,
    onSurface = TextPrimary,
    surfaceVariant = CharcoalCard,
    onSurfaceVariant = TextSecondary
)

val CarromTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 26.sp,
        color = TextPrimary
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        color = TextPrimary
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        color = TextPrimary
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        color = TextPrimary
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        color = TextSecondary
    )
)

@Composable
fun CarromVisionTheme(
    accentMode: String = "GOLD",
    content: @Composable () -> Unit
) {
    val scheme = if (accentMode == "CRIMSON") CrimsonDarkColorScheme else GoldDarkColorScheme
    MaterialTheme(
        colorScheme = scheme,
        typography = CarromTypography,
        content = content
    )
}
