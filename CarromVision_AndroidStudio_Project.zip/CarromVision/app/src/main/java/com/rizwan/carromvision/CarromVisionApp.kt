package com.rizwan.carromvision

import android.app.Application
import android.util.Log
import org.opencv.android.OpenCVLoader

class CarromVisionApp : Application() {

    var isOpenCvInitialized: Boolean = false
        private set

    override fun onCreate() {
        super.onCreate()
        isOpenCvInitialized = try {
            OpenCVLoader.initLocal()
        } catch (t: Throwable) {
            Log.w("CarromVisionApp", "OpenCV native library fallback active: ${t.message}")
            false
        }
    }
}
