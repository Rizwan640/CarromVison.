package com.rizwan.carromvision.data.repository

import com.google.gson.Gson
import com.rizwan.carromvision.data.database.AnalysisDao
import com.rizwan.carromvision.data.database.AnalysisEntity
import com.rizwan.carromvision.domain.models.DetectedObject
import com.rizwan.carromvision.domain.models.ShotSuggestion
import kotlinx.coroutines.flow.Flow

class AnalysisRepository(
    private val analysisDao: AnalysisDao,
    private val gson: Gson = Gson()
) {
    val allAnalyses: Flow<List<AnalysisEntity>> = analysisDao.observeAllAnalyses()

    suspend fun saveAnalysis(
        screenshotUri: String?,
        retainScreenshot: Boolean,
        detectedObjects: List<DetectedObject>,
        selectedShot: ShotSuggestion,
        notes: String = ""
    ): Long {
        val entity = AnalysisEntity(
            timestampMillis = System.currentTimeMillis(),
            screenshotUri = if (retainScreenshot) screenshotUri else null,
            detectedObjectsJson = gson.toJson(detectedObjects),
            selectedTargetId = selectedShot.targetCoin.id,
            selectedTargetType = selectedShot.targetCoin.type.name,
            selectedPocketId = selectedShot.targetPocket.id,
            selectedPocketName = selectedShot.targetPocket.name,
            calculatedShotAngleDeg = selectedShot.requiredAngleDegrees,
            shotType = selectedShot.shotType.name,
            confidenceScore = selectedShot.confidenceScore,
            trajectoryJson = gson.toJson(selectedShot.coinPath),
            userNotes = notes
        )
        return analysisDao.insertAnalysis(entity)
    }

    suspend fun deleteAnalysis(id: Long) {
        analysisDao.deleteAnalysisById(id)
    }

    suspend fun clearAllHistory() {
        analysisDao.clearAllAnalyses()
    }
}
