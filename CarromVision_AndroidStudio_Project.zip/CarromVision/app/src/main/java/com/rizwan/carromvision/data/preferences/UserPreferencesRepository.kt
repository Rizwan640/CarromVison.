package com.rizwan.carromvision.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.rizwan.carromvision.domain.models.PhysicsConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "carrom_vision_prefs")

data class AppPreferences(
    val physicsConfig: PhysicsConfig = PhysicsConfig(),
    val retainScreenshotsInHistory: Boolean = false,
    val accentTheme: String = "GOLD", // GOLD or CRIMSON
    val activeCalibrationProfileJson: String = ""
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val INITIAL_VELOCITY = doublePreferencesKey("initial_velocity")
        val FRICTION_COEFF = doublePreferencesKey("friction_coeff")
        val RESTITUTION_COIN = doublePreferencesKey("restitution_coin")
        val RESTITUTION_CUSHION = doublePreferencesKey("restitution_cushion")
        val COLLISION_DAMPING = doublePreferencesKey("collision_damping")
        val CPU_FRIENDLY_MODE = booleanPreferencesKey("cpu_friendly_mode")
        val MAX_RESOLUTION = intPreferencesKey("max_resolution")
        val DETECTION_SENSITIVITY = doublePreferencesKey("detection_sensitivity")
        val RETAIN_SCREENSHOTS = booleanPreferencesKey("retain_screenshots")
        val ACCENT_THEME = stringPreferencesKey("accent_theme")
        val CALIBRATION_JSON = stringPreferencesKey("calibration_json")
    }

    val preferencesFlow: Flow<AppPreferences> = context.dataStore.data.map { prefs ->
        val physics = PhysicsConfig(
            initialVelocity = prefs[Keys.INITIAL_VELOCITY] ?: 1.65,
            frictionCoefficient = prefs[Keys.FRICTION_COEFF] ?: 0.18,
            restitutionCoinCoin = prefs[Keys.RESTITUTION_COIN] ?: 0.88,
            restitutionCushion = prefs[Keys.RESTITUTION_CUSHION] ?: 0.78,
            collisionDamping = prefs[Keys.COLLISION_DAMPING] ?: 0.92,
            cpuFriendlyMode = prefs[Keys.CPU_FRIENDLY_MODE] ?: true,
            maxProcessingResolution = prefs[Keys.MAX_RESOLUTION] ?: 960,
            detectionSensitivity = prefs[Keys.DETECTION_SENSITIVITY] ?: 0.65
        )
        AppPreferences(
            physicsConfig = physics,
            retainScreenshotsInHistory = prefs[Keys.RETAIN_SCREENSHOTS] ?: false,
            accentTheme = prefs[Keys.ACCENT_THEME] ?: "GOLD",
            activeCalibrationProfileJson = prefs[Keys.CALIBRATION_JSON] ?: ""
        )
    }

    suspend fun updatePhysicsConfig(config: PhysicsConfig) {
        context.dataStore.edit { prefs ->
            prefs[Keys.INITIAL_VELOCITY] = config.initialVelocity
            prefs[Keys.FRICTION_COEFF] = config.frictionCoefficient
            prefs[Keys.RESTITUTION_COIN] = config.restitutionCoinCoin
            prefs[Keys.RESTITUTION_CUSHION] = config.restitutionCushion
            prefs[Keys.COLLISION_DAMPING] = config.collisionDamping
            prefs[Keys.CPU_FRIENDLY_MODE] = config.cpuFriendlyMode
            prefs[Keys.MAX_RESOLUTION] = config.maxProcessingResolution
            prefs[Keys.DETECTION_SENSITIVITY] = config.detectionSensitivity
        }
    }

    suspend fun updatePrivacyRetainScreenshots(retain: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.RETAIN_SCREENSHOTS] = retain
        }
    }

    suspend fun updateAccentTheme(theme: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.ACCENT_THEME] = theme
        }
    }

    suspend fun saveCalibrationProfileJson(json: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.CALIBRATION_JSON] = json
        }
    }
}
