package com.rizwan.carromvision.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rizwan.carromvision.calibration.CalibrationProfile
import com.rizwan.carromvision.data.preferences.AppPreferences
import com.rizwan.carromvision.domain.models.PhysicsConfig
import com.rizwan.carromvision.ui.theme.CharcoalCard
import com.rizwan.carromvision.ui.theme.SubtleCrimson
import com.rizwan.carromvision.ui.theme.SubtleGold

/**
 * Screen 5: Settings — Detection sensitivity, Image processing quality, Physics configuration,
 * Manual calibration reset, Theme selection, History management, Privacy settings, and About section.
 */
@Composable
fun SettingsScreen(
    preferences: AppPreferences,
    onUpdatePhysicsConfig: (PhysicsConfig) -> Unit,
    onUpdateRetainScreenshots: (Boolean) -> Unit,
    onUpdateAccentTheme: (String) -> Unit,
    onResetCalibrationProfile: (CalibrationProfile) -> Unit,
    onClearHistoryClick: () -> Unit,
    onBackClick: () -> Unit
) {
    val physics = preferences.physicsConfig

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Column {
                    Text(
                        text = "Settings & Calibration",
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Text(
                        text = "Configure OpenCV detection, physics constants & local privacy",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            // 1. Detection Sensitivity & Image Processing Quality
            SettingsSectionCard(title = "Computer Vision & CPU Optimization") {
                Text(
                    text = "Detection Sensitivity: ${"%.2f".format(physics.detectionSensitivity)}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Slider(
                    value = physics.detectionSensitivity.toFloat(),
                    onValueChange = {
                        onUpdatePhysicsConfig(physics.copy(detectionSensitivity = it.toDouble()))
                    },
                    valueRange = 0.40f..0.90f
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("CPU-Friendly Processing Mode", style = MaterialTheme.typography.bodyMedium)
                        Text("Downscales frames to 640px for low-RAM devices", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(
                        checked = physics.cpuFriendlyMode,
                        onCheckedChange = {
                            onUpdatePhysicsConfig(
                                physics.copy(
                                    cpuFriendlyMode = it,
                                    maxProcessingResolution = if (it) 640 else 1080
                                )
                            )
                        }
                    )
                }
            }

            // 2. Physics Configuration
            SettingsSectionCard(title = "Carrom Physics Engine Parameters") {
                Text(
                    text = "Surface Friction Coefficient (μ): ${"%.2f".format(physics.frictionCoefficient)}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Slider(
                    value = physics.frictionCoefficient.toFloat(),
                    onValueChange = {
                        onUpdatePhysicsConfig(physics.copy(frictionCoefficient = it.toDouble()))
                    },
                    valueRange = 0.08f..0.35f
                )

                Text(
                    text = "Cushion Restitution (e_cushion): ${"%.2f".format(physics.restitutionCushion)}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Slider(
                    value = physics.restitutionCushion.toFloat(),
                    onValueChange = {
                        onUpdatePhysicsConfig(physics.copy(restitutionCushion = it.toDouble()))
                    },
                    valueRange = 0.55f..0.95f
                )

                Text(
                    text = "Coin-Coin Restitution (e_coin): ${"%.2f".format(physics.restitutionCoinCoin)}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Slider(
                    value = physics.restitutionCoinCoin.toFloat(),
                    onValueChange = {
                        onUpdatePhysicsConfig(physics.copy(restitutionCoinCoin = it.toDouble()))
                    },
                    valueRange = 0.65f..0.98f
                )
            }

            // 3. Manual Calibration & Theme Selection
            SettingsSectionCard(title = "Calibration Profile & Accent Theme") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilterChip(
                        selected = preferences.accentTheme == "GOLD",
                        onClick = { onUpdateAccentTheme("GOLD") },
                        label = { Text("Subtle Gold Accent") }
                    )
                    FilterChip(
                        selected = preferences.accentTheme == "CRIMSON",
                        onClick = { onUpdateAccentTheme("CRIMSON") },
                        label = { Text("Crimson Red Accent") }
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { onResetCalibrationProfile(CalibrationProfile()) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Reset Board & Pocket Calibration to Default")
                }
            }

            // 4. Privacy & History Management
            SettingsSectionCard(title = "Privacy & Local History Controls") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Retain Screenshot References", style = MaterialTheme.typography.bodyMedium)
                        Text("Store screenshot URI when saving analysis history", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(
                        checked = preferences.retainScreenshotsInHistory,
                        onCheckedChange = onUpdateRetainScreenshots
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onClearHistoryClick,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Delete All Saved Analysis History")
                }
            }

            // 5. About Application
            SettingsSectionCard(title = "About Carrom Vision") {
                Text(
                    text = "Application: Carrom Vision (com.rizwan.carromvision)",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SubtleGold
                )
                Text(
                    text = "Developer Credit: Khan Rizwan",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = "Architecture: MVVM + Clean Architecture • Jetpack Compose • OpenCV 4.9 • Room & DataStore",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    text = "Security Guarantee: Operates 100% offline on-device. Does not require root access, never accesses game memory, and renders guidelines strictly inside the Carrom Vision workspace.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = SubtleGold
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}
