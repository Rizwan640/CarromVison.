package com.rizwan.carromvision.ui.home

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rizwan.carromvision.capture.CaptureStatus
import com.rizwan.carromvision.ui.theme.CharcoalBackground
import com.rizwan.carromvision.ui.theme.CharcoalCard
import com.rizwan.carromvision.ui.theme.SubtleCrimson
import com.rizwan.carromvision.ui.theme.SubtleGold
import com.rizwan.carromvision.ui.theme.TextSecondary
import kotlinx.coroutines.delay

/**
 * Screen 1: Splash Screen displaying Carrom Vision emblem, application title, and smooth loading animation.
 */
@Composable
fun SplashScreen(onSplashFinished: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "splash_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    LaunchedEffect(Unit) {
        delay(1200L)
        onSplashFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBackground),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .scale(pulseScale),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(
                        color = SubtleGold,
                        radius = size.minDimension * 0.46f,
                        style = Stroke(width = 6f)
                    )
                    drawCircle(
                        color = SubtleGold.copy(alpha = 0.4f),
                        radius = size.minDimension * 0.30f,
                        style = Stroke(width = 3f)
                    )
                    drawCircle(
                        color = SubtleCrimson,
                        radius = size.minDimension * 0.14f
                    )
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "CARROM VISION",
                style = MaterialTheme.typography.headlineLarge,
                color = SubtleGold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Visual Physics & Trajectory Analysis Engine",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(28.dp))
            CircularProgressIndicator(
                color = SubtleGold,
                strokeWidth = 2.5.dp,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

/**
 * Screen 2: Home Dashboard with all 6 primary navigation sections and capability overview.
 */
@Composable
fun HomeDashboardScreen(
    captureStatus: CaptureStatus,
    onStartAnalysisClick: () -> Unit,
    onLiveScreenCaptureClick: () -> Unit,
    onImportScreenshotClick: () -> Unit,
    onPracticeModeClick: () -> Unit,
    onHistoryClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            // Top Branding Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Carrom Vision",
                        style = MaterialTheme.typography.headlineLarge
                    )
                    Text(
                        text = "On-Device Computer Vision & Shot Mechanics",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "v1.0 • Offline",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Brief Capabilities Overview Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Analytical Aiming Workspace",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Carrom Vision detects the playing board, pockets, white/black coins, red queen, and striker using OpenCV HSV and geometric contour segmentation. It computes ghost-ball contact normals, single/double cushion reflections, and momentum transfers entirely on-device.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 6 Dashboard Sections Grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.weight(1f)
            ) {
                item {
                    DashboardFeatureCard(
                        title = "Start Analysis",
                        subtitle = "Open active workspace & trajectory canvas",
                        icon = Icons.Default.Analytics,
                        accentColor = MaterialTheme.colorScheme.primary,
                        onClick = onStartAnalysisClick
                    )
                }
                item {
                    DashboardFeatureCard(
                        title = "Live Screen Analysis",
                        subtitle = "Authorized MediaProjection frame capture (${captureStatus.name})",
                        icon = Icons.Default.CameraAlt,
                        accentColor = SubtleCrimson,
                        onClick = onLiveScreenCaptureClick
                    )
                }
                item {
                    DashboardFeatureCard(
                        title = "Import Screenshot",
                        subtitle = "Load Carrom Pool screenshot from gallery",
                        icon = Icons.Default.PhotoLibrary,
                        accentColor = MaterialTheme.colorScheme.primary,
                        onClick = onImportScreenshotClick
                    )
                }
                item {
                    DashboardFeatureCard(
                        title = "Practice Mode",
                        subtitle = "Test physics & bank shots on synthetic layouts",
                        icon = Icons.Default.School,
                        accentColor = Color(0xFF4CAF50),
                        onClick = onPracticeModeClick
                    )
                }
                item {
                    DashboardFeatureCard(
                        title = "Analysis History",
                        subtitle = "Review saved board coordinates & shots",
                        icon = Icons.Default.History,
                        accentColor = Color(0xFF26C6DA),
                        onClick = onHistoryClick
                    )
                }
                item {
                    DashboardFeatureCard(
                        title = "Settings",
                        subtitle = "Physics parameters, calibration & privacy",
                        icon = Icons.Default.Settings,
                        accentColor = TextSecondary,
                        onClick = onSettingsClick
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Developed by Khan Rizwan • Independent On-Device Processing • Zero Game Memory Access",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }
}

@Composable
private fun DashboardFeatureCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(142.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2
                )
            }
        }
    }
}
