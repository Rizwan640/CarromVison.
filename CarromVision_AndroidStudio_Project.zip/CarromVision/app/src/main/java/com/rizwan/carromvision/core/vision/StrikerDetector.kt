package com.rizwan.carromvision.core.vision

import android.graphics.Bitmap
import android.graphics.Color
import com.rizwan.carromvision.domain.models.DetectedObject
import com.rizwan.carromvision.domain.models.ObjectType
import com.rizwan.carromvision.domain.models.PhysicsConfig
import com.rizwan.carromvision.domain.models.Point2D
import kotlin.math.sqrt

/**
 * Identifies the Carrom Striker using circular shape detection, larger radius comparison
 * (striker radius ≈ 1.25x–1.40x coin radius), distinctive color/saturation, and baseline position.
 */
class StrikerDetector {

    fun detectStriker(
        warpedBoardBitmap: Bitmap,
        detectedCoins: List<DetectedObject>,
        config: PhysicsConfig
    ): DetectedObject? {
        val width = warpedBoardBitmap.width
        val height = warpedBoardBitmap.height
        if (width < 64 || height < 64) return null

        val step = if (width >= 600) 2 else 1
        val gridW = width / step
        val gridH = height / step

        val strikerMask = BooleanArray(gridW * gridH)
        val hsv = FloatArray(3)

        for (gy in 0 until gridH) {
            val py = gy * step
            val ny = py.toDouble() / height
            for (gx in 0 until gridW) {
                val px = gx * step
                val nx = px.toDouble() / width

                // Search player baseline and active board area
                if (nx < 0.08 || nx > 0.92 || ny < 0.12 || ny > 0.92) continue

                val pixel = warpedBoardBitmap.getPixel(px, py)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)
                Color.RGBToHSV(r, g, b, hsv)
                val hue = hsv[0]
                val sat = hsv[1]
                val value = hsv[2]

                // Striker appearance: distinctive cyan/teal/gold/neon ring or bright disc outside standard coin colors
                val isStrikerColor = (hue in 165f..215f && sat >= 0.45f && value >= 0.50f) ||
                    (hue in 38f..62f && sat >= 0.65f && value >= 0.72f)
                if (isStrikerColor) {
                    strikerMask[gy * gridW + gx] = true
                }
            }
        }

        val visited = BooleanArray(gridW * gridH)
        val queueX = IntArray(gridW * gridH)
        val queueY = IntArray(gridW * gridH)

        var bestCandidate: DetectedObject? = null
        var bestScore = 0.0

        val expectedRadius = config.defaultStrikerRadius
        val minStrikerRadius = expectedRadius * 0.70
        val maxStrikerRadius = expectedRadius * 1.40

        for (gy in 1 until gridH - 1) {
            for (gx in 1 until gridW - 1) {
                val idx = gy * gridW + gx
                if (!strikerMask[idx] || visited[idx]) continue

                var head = 0
                var tail = 0
                queueX[tail] = gx
                queueY[tail] = gy
                tail++
                visited[idx] = true

                var sumX = 0.0
                var sumY = 0.0

                while (head < tail) {
                    val cx = queueX[head]
                    val cy = queueY[head]
                    head++
                    sumX += cx
                    sumY += cy

                    val neighbors = arrayOf(
                        Pair(cx + 1, cy),
                        Pair(cx - 1, cy),
                        Pair(cx, cy + 1),
                        Pair(cx, cy - 1)
                    )
                    for ((nxGrid, nyGrid) in neighbors) {
                        if (nxGrid in 0 until gridW && nyGrid in 0 until gridH) {
                            val nIdx = nyGrid * gridW + nxGrid
                            if (!visited[nIdx] && strikerMask[nIdx]) {
                                visited[nIdx] = true
                                queueX[tail] = nxGrid
                                queueY[tail] = nyGrid
                                tail++
                            }
                        }
                    }
                }

                val pixelCount = tail
                val areaNorm = (pixelCount * step * step).toDouble() / (width.toDouble() * height.toDouble())
                val radiusNorm = sqrt(areaNorm / Math.PI)

                if (radiusNorm in minStrikerRadius..maxStrikerRadius) {
                    val centerXNorm = ((sumX / pixelCount) * step) / width.toDouble()
                    val centerYNorm = ((sumY / pixelCount) * step) / height.toDouble()
                    val candidatePt = Point2D(centerXNorm, centerYNorm)

                    // Ensure it doesn't overlap an already classified coin
                    val overlapsCoin = detectedCoins.any { it.center.distanceTo(candidatePt) < 0.025 }
                    if (!overlapsCoin) {
                        // Bonus confidence if located along bottom or top player baseline (y in 0.74..0.88 or 0.12..0.26)
                        val onBaseline = centerYNorm in 0.74..0.88 || centerYNorm in 0.12..0.26
                        val sizeMatch = 1.0 - (kotlin.math.abs(radiusNorm - expectedRadius) / expectedRadius).coerceIn(0.0, 0.5)
                        val score = (sizeMatch * 0.75 + if (onBaseline) 0.22 else 0.08).coerceIn(0.50, 0.98)

                        if (score > bestScore) {
                            bestScore = score
                            bestCandidate = DetectedObject(
                                id = "striker_main",
                                type = ObjectType.STRIKER,
                                x = centerXNorm,
                                y = centerYNorm,
                                radius = radiusNorm,
                                confidence = score
                            )
                        }
                    }
                }
            }
        }

        return bestCandidate
    }
}
