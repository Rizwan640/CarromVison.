package com.rizwan.carromvision

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.rizwan.carromvision.capture.MediaProjectionService
import com.rizwan.carromvision.capture.ScreenCaptureManager
import com.rizwan.carromvision.data.database.CarromDatabase
import com.rizwan.carromvision.data.preferences.UserPreferencesRepository
import com.rizwan.carromvision.data.repository.AnalysisRepository
import com.rizwan.carromvision.domain.models.ObjectType
import com.rizwan.carromvision.ui.CarromVisionViewModel
import com.rizwan.carromvision.ui.analysis.AnalysisWorkspaceScreen
import com.rizwan.carromvision.ui.history.HistoryScreen
import com.rizwan.carromvision.ui.home.HomeDashboardScreen
import com.rizwan.carromvision.ui.home.SplashScreen
import com.rizwan.carromvision.ui.results.AnalysisResultsScreen
import com.rizwan.carromvision.ui.settings.SettingsScreen
import com.rizwan.carromvision.ui.theme.CarromVisionTheme

class MainActivity : ComponentActivity() {

    private lateinit var screenCaptureManager: ScreenCaptureManager

    private val viewModel: CarromVisionViewModel by viewModels {
        val db = CarromDatabase.getInstance(applicationContext)
        val prefsRepo = UserPreferencesRepository(applicationContext)
        val analysisRepo = AnalysisRepository(db.analysisDao())
        screenCaptureManager = ScreenCaptureManager(applicationContext)
        CarromVisionViewModel.Factory(
            preferencesRepository = prefsRepo,
            analysisRepository = analysisRepo,
            screenCaptureManager = screenCaptureManager
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val prefs by viewModel.appPreferences.collectAsState()
            val workspaceState by viewModel.workspaceState.collectAsState()
            val historyItems by viewModel.historyList.collectAsState()
            val captureStatus by viewModel.captureStatus.collectAsState()
            val navController = rememberNavController()

            // Photo Picker Launcher for importing Carrom Pool screenshots
            val photoPickerLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.PickVisualMedia()
            ) { uri: Uri? ->
                if (uri != null) {
                    contentResolver.openInputStream(uri)?.use { stream ->
                        val bitmap = BitmapFactory.decodeStream(stream)
                        if (bitmap != null) {
                            viewModel.onScreenshotImported(bitmap)
                            navController.navigate("workspace") {
                                launchSingleTop = true
                            }
                        }
                    }
                }
            }

            // MediaProjection Explicit Permission Launcher
            val mediaProjectionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.StartActivityForResult()
            ) { result ->
                if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                    val serviceIntent = Intent(this, MediaProjectionService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(serviceIntent)
                    } else {
                        startService(serviceIntent)
                    }
                    screenCaptureManager.onPermissionGranted(result.resultCode, result.data!!)
                    val metrics = resources.displayMetrics
                    screenCaptureManager.captureSingleFrame(
                        screenWidth = metrics.widthPixels,
                        screenHeight = metrics.heightPixels,
                        screenDensityDpi = metrics.densityDpi
                    ) { capturedBitmap ->
                        if (capturedBitmap != null) {
                            viewModel.onScreenshotImported(capturedBitmap)
                            navController.navigate("workspace") {
                                launchSingleTop = true
                            }
                        }
                    }
                } else {
                    screenCaptureManager.onPermissionDenied()
                }
            }

            // Initialize default practice board so workspace is immediately interactive
            LaunchedEffect(Unit) {
                if (workspaceState.sourceBitmap == null) {
                    viewModel.loadPracticeBoard(nextPreset = false)
                }
            }

            CarromVisionTheme(accentMode = prefs.accentTheme) {
                NavHost(
                    navController = navController,
                    startDestination = "splash"
                ) {
                    composable("splash") {
                        SplashScreen(
                            onSplashFinished = {
                                navController.navigate("home") {
                                    popUpTo("splash") { inclusive = true }
                                }
                            }
                        )
                    }

                    composable("home") {
                        HomeDashboardScreen(
                            captureStatus = captureStatus,
                            onStartAnalysisClick = { navController.navigate("workspace") },
                            onLiveScreenCaptureClick = {
                                val intent = screenCaptureManager.createScreenCaptureIntent()
                                if (intent != null) {
                                    mediaProjectionLauncher.launch(intent)
                                }
                            },
                            onImportScreenshotClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            onPracticeModeClick = {
                                viewModel.loadPracticeBoard(nextPreset = false)
                                navController.navigate("workspace")
                            },
                            onHistoryClick = { navController.navigate("history") },
                            onSettingsClick = { navController.navigate("settings") }
                        )
                    }

                    composable("workspace") {
                        AnalysisWorkspaceScreen(
                            state = workspaceState,
                            onBackClick = { navController.popBackStack() },
                            onImportScreenshotClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            onDetectObjectsClick = { viewModel.detectObjectsOnCurrentBitmap() },
                            onRecalculateClick = { viewModel.recalculateTrajectories() },
                            onResetClick = { viewModel.resetWorkspace() },
                            onToggleManualAdjustment = { viewModel.toggleManualAdjustmentMode() },
                            onSelectNextTarget = {
                                val candidateCoins = workspaceState.detectedObjects.filter { it.type != ObjectType.STRIKER }
                                if (candidateCoins.isNotEmpty()) {
                                    val currentIdx = candidateCoins.indexOfFirst { it.id == workspaceState.selectedTargetCoinId }
                                    val nextCoin = candidateCoins[(currentIdx + 1) % candidateCoins.size]
                                    viewModel.selectTargetCoin(nextCoin.id)
                                }
                            },
                            onToggleAlternativeShots = {
                                viewModel.toggleGuidelineLayer { it.copy(showAlternativeShots = !it.showAlternativeShots) }
                            },
                            onToggleDirectShots = {
                                viewModel.toggleGuidelineLayer { it.copy(showDirectShots = !it.showDirectShots) }
                            },
                            onToggleBankShots = {
                                viewModel.toggleGuidelineLayer { it.copy(showBankShots = !it.showBankShots) }
                            },
                            onTogglePredictedStriker = {
                                viewModel.toggleGuidelineLayer { it.copy(showPredictedStrikerPath = !it.showPredictedStrikerPath) }
                            },
                            onBoardTapOrDrag = { nx, ny -> viewModel.onBoardTapOrDragNormalized(nx, ny) },
                            onReclassifySelectedObject = { newType -> viewModel.reclassifySelectedObject(newType) },
                            onOpenDetailedResultsClick = { navController.navigate("results") },
                            onSaveAnalysisClick = { viewModel.saveCurrentAnalysisToHistory() },
                            onCyclePracticePreset = { viewModel.loadPracticeBoard(nextPreset = true) }
                        )
                    }

                    composable("results") {
                        AnalysisResultsScreen(
                            state = workspaceState,
                            onSelectShotIndex = { idx -> viewModel.selectShotIndex(idx) },
                            onBackToWorkspace = { navController.popBackStack() }
                        )
                    }

                    composable("history") {
                        HistoryScreen(
                            historyItems = historyItems,
                            onDeleteItem = { id -> viewModel.deleteHistoryItem(id) },
                            onClearAll = { viewModel.clearAllHistory() },
                            onBackClick = { navController.popBackStack() }
                        )
                    }

                    composable("settings") {
                        SettingsScreen(
                            preferences = prefs,
                            onUpdatePhysicsConfig = { cfg -> viewModel.updatePhysicsConfig(cfg) },
                            onUpdateRetainScreenshots = { retain -> viewModel.updateRetainScreenshots(retain) },
                            onUpdateAccentTheme = { theme -> viewModel.updateAccentTheme(theme) },
                            onResetCalibrationProfile = { prof -> viewModel.saveManualCalibrationProfile(prof) },
                            onClearHistoryClick = { viewModel.clearAllHistory() },
                            onBackClick = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
