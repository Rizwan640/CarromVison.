package com.rizwan.carromvision.core.rendering

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import com.rizwan.carromvision.domain.models.BoardGeometry
import com.rizwan.carromvision.domain.models.DetectedObject
import com.rizwan.carromvision.domain.models.GuidelineLayerConfig
import com.rizwan.carromvision.domain.models.ObjectType
import com.rizwan.carromvision.domain.models.ShotSuggestion
import com.rizwan.carromvision.domain.models.ShotType
import com.rizwan.carromvision.ui.theme.BankShotAmber
import com.rizwan.carromvision.ui.theme.CollisionCyan
import com.rizwan.carromvision.ui.theme.DirectShotGreen
import com.rizwan.carromvision.ui.theme.SubtleCrimson
import com.rizwan.carromvision.ui.theme.SubtleGold
import com.rizwan.carromvision.ui.theme.UncertainMutedRed

/**
 * Dedicated Jetpack Compose Canvas trajectory and object detection visualization engine.
 * Renders normalized board coordinates [0.0, 1.0] cleanly inside the Analysis Workspace.
 */
object TrajectoryRenderer {

    @Composable
    fun BoardAnalysisCanvas(
        boardGeometry: BoardGeometry?,
        detectedObjects: List<DetectedObject>,
        shotSuggestions: List<ShotSuggestion>,
        activeShotIndex: Int,
        layerConfig: GuidelineLayerConfig,
        selectedTargetCoinId: String?,
        selectedPocketId: Int?,
        onNormalizedTapOrDrag: (Double, Double) -> Unit,
        modifier: Modifier = Modifier
    ) {
        Canvas(
            modifier = modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        if (size.width > 0 && size.height > 0) {
                            val nx = (offset.x / size.width.toDouble()).coerceIn(0.0, 1.0)
                            val ny = (offset.y / size.height.toDouble()).coerceIn(0.0, 1.0)
                            onNormalizedTapOrDrag(nx, ny)
                        }
                    }
                }
                .pointerInput(Unit) {
                    detectDragGestures { change, _ ->
                        change.consume()
                        if (size.width > 0 && size.height > 0) {
                            val nx = (change.position.x / size.width.toDouble()).coerceIn(0.0, 1.0)
                            val ny = (change.position.y / size.height.toDouble()).coerceIn(0.0, 1.0)
                            onNormalizedTapOrDrag(nx, ny)
                        }
                    }
                }
        ) {
            val w = size.width
            val h = size.height

            // 1. Draw Normalized Playing Surface Boundary
            drawRect(
                color = SubtleGold.copy(alpha = 0.55f),
                topLeft = Offset(0f, 0f),
                size = Size(w, h),
                style = Stroke(width = 3f)
            )

            // 2. Draw Four Corner Pockets
            if (layerConfig.showPocketZones && boardGeometry != null) {
                for (pocket in boardGeometry.pockets) {
                    val px = (pocket.x * w).toFloat()
                    val py = (pocket.y * h).toFloat()
                    val pr = (pocket.radius * w).toFloat()
                    val isSelectedPocket = pocket.id == selectedPocketId
                    drawCircle(
                        color = if (isSelectedPocket) SubtleGold else Color(0xFF80CBC4).copy(alpha = 0.7f),
                        radius = pr,
                        center = Offset(px, py),
                        style = Stroke(width = if (isSelectedPocket) 5f else 2.5f)
                    )
                }
            }

            // 3. Draw Alternative Shot Trajectories (if enabled)
            if (layerConfig.showAlternativeShots && shotSuggestions.size > 1) {
                shotSuggestions.forEachIndexed { idx, shot ->
                    if (idx != activeShotIndex) {
                        drawShotTrajectory(
                            shot = shot,
                            canvasWidth = w,
                            canvasHeight = h,
                            layerConfig = layerConfig,
                            isPrimary = false
                        )
                    }
                }
            }

            // 4. Draw Primary Active Shot Trajectory
            val primaryShot = shotSuggestions.getOrNull(activeShotIndex)
            if (primaryShot != null) {
                drawShotTrajectory(
                    shot = primaryShot,
                    canvasWidth = w,
                    canvasHeight = h,
                    layerConfig = layerConfig,
                    isPrimary = true
                )
            }

            // 5. Draw Detected Coins, Red Queen, and Striker
            for (obj in detectedObjects) {
                val cx = (obj.x * w).toFloat()
                val cy = (obj.y * h).toFloat()
                val cr = (obj.radius * w).toFloat().coerceAtLeast(8f)
                val isSelectedTarget = obj.id == selectedTargetCoinId || obj.id == primaryShot?.targetCoin?.id

                val ringColor = when (obj.type) {
                    ObjectType.WHITE_COIN -> Color(0xFFF5F5F5)
                    ObjectType.BLACK_COIN -> Color(0xFF90A4AE)
                    ObjectType.RED_QUEEN -> SubtleCrimson
                    ObjectType.STRIKER -> CollisionCyan
                    ObjectType.POCKET -> SubtleGold
                }

                // Outer selection glow if target coin
                if (isSelectedTarget && obj.type != ObjectType.STRIKER) {
                    drawCircle(
                        color = SubtleGold,
                        radius = cr + 6f,
                        center = Offset(cx, cy),
                        style = Stroke(
                            width = 3.5f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f), 0f)
                        )
                    )
                }

                drawCircle(
                    color = ringColor,
                    radius = cr,
                    center = Offset(cx, cy),
                    style = Stroke(width = if (obj.type == ObjectType.STRIKER) 4f else 3f)
                )

                // Center crosshair dot
                drawCircle(
                    color = ringColor,
                    radius = 3.5f,
                    center = Offset(cx, cy)
                )
            }
        }
    }

    private fun DrawScope.drawShotTrajectory(
        shot: ShotSuggestion,
        canvasWidth: Float,
        canvasHeight: Float,
        layerConfig: GuidelineLayerConfig,
        isPrimary: Boolean
    ) {
        if (shot.isUncertain && !layerConfig.showUncertainPredictions) return
        if (shot.shotType == ShotType.DIRECT_SHOT && !layerConfig.showDirectShots) return
        if ((shot.shotType == ShotType.SINGLE_BANK_SHOT || shot.shotType == ShotType.DOUBLE_BANK_SHOT) && !layerConfig.showBankShots) return

        val alphaMul = if (isPrimary) 1.0f else 0.35f
        val dashPattern = PathEffect.dashPathEffect(floatArrayOf(14f, 8f), 0f)
        val uncertainDash = PathEffect.dashPathEffect(floatArrayOf(6f, 10f), 0f)

        val baseShotColor = when {
            shot.isUncertain -> UncertainMutedRed
            shot.shotType == ShotType.DIRECT_SHOT -> DirectShotGreen
            shot.shotType == ShotType.SINGLE_BANK_SHOT || shot.shotType == ShotType.DOUBLE_BANK_SHOT -> BankShotAmber
            else -> CollisionCyan
        }.copy(alpha = alphaMul)

        // A. Draw Striker Aiming Line (from Striker center to Ghost-ball contact point)
        for (segment in shot.strikerPath) {
            val startOffset = Offset(
                (segment.start.x * canvasWidth).toFloat(),
                (segment.start.y * canvasHeight).toFloat()
            )
            val endOffset = Offset(
                (segment.end.x * canvasWidth).toFloat(),
                (segment.end.y * canvasHeight).toFloat()
            )
            drawLine(
                color = if (segment.isCushionRebound) BankShotAmber.copy(alpha = alphaMul) else SubtleGold.copy(alpha = alphaMul),
                start = startOffset,
                end = endOffset,
                strokeWidth = if (isPrimary) 4.5f else 2.5f,
                pathEffect = if (segment.isCushionRebound) dashPattern else null
            )
        }

        // B. Draw Ghost-Ball Contact Point Circle
        if (layerConfig.showCollisionPaths) {
            val ghostX = (shot.requiredContactPoint.x * canvasWidth).toFloat()
            val ghostY = (shot.requiredContactPoint.y * canvasHeight).toFloat()
            val strikerRadiusPx = (0.038f * canvasWidth)
            drawCircle(
                color = CollisionCyan.copy(alpha = 0.8f * alphaMul),
                radius = strikerRadiusPx,
                center = Offset(ghostX, ghostY),
                style = Stroke(width = 2.5f, pathEffect = dashPattern)
            )

            // Impact point marker between striker surface and target coin surface
            val impactX = (shot.collisionPrediction.impactPoint.x * canvasWidth).toFloat()
            val impactY = (shot.collisionPrediction.impactPoint.y * canvasHeight).toFloat()
            drawCircle(
                color = SubtleCrimson.copy(alpha = alphaMul),
                radius = if (isPrimary) 5.5f else 3.5f,
                center = Offset(impactX, impactY)
            )
        }

        // C. Draw Target Coin Movement Path (including Cushion Rebound segments)
        for (segment in shot.coinPath) {
            val startOffset = Offset(
                (segment.start.x * canvasWidth).toFloat(),
                (segment.start.y * canvasHeight).toFloat()
            )
            val endOffset = Offset(
                (segment.end.x * canvasWidth).toFloat(),
                (segment.end.y * canvasHeight).toFloat()
            )
            drawLine(
                color = baseShotColor,
                start = startOffset,
                end = endOffset,
                strokeWidth = if (isPrimary) 5f else 2.5f,
                pathEffect = when {
                    shot.isUncertain -> uncertainDash
                    segment.isCushionRebound -> dashPattern
                    else -> null
                }
            )
        }

        // D. Draw Post-Collision Striker Deflection Trajectory & Final Position
        if (layerConfig.showPredictedStrikerPath && isPrimary) {
            for (segment in shot.strikerPostCollisionPath) {
                val startOffset = Offset(
                    (segment.start.x * canvasWidth).toFloat(),
                    (segment.start.y * canvasHeight).toFloat()
                )
                val endOffset = Offset(
                    (segment.end.x * canvasWidth).toFloat(),
                    (segment.end.y * canvasHeight).toFloat()
                )
                drawLine(
                    color = CollisionCyan.copy(alpha = 0.65f),
                    start = startOffset,
                    end = endOffset,
                    strokeWidth = 3f,
                    pathEffect = dashPattern
                )
            }
            val finalStrikerOffset = Offset(
                (shot.estimatedStrikerFinalPos.x * canvasWidth).toFloat(),
                (shot.estimatedStrikerFinalPos.y * canvasHeight).toFloat()
            )
            drawCircle(
                color = CollisionCyan.copy(alpha = 0.55f),
                radius = 0.032f * canvasWidth,
                center = finalStrikerOffset,
                style = Stroke(width = 2f, pathEffect = uncertainDash)
            )
        }
    }
}
