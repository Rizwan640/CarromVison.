package com.rizwan.carromvision.ui.analysis

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rizwan.carromvision.core.rendering.TrajectoryRenderer
import com.rizwan.carromvision.domain.models.ObjectType
import com.rizwan.carromvision.ui.WorkspaceUiState
import com.rizwan.carromvision.ui.theme.CharcoalCard
import com.rizwan.carromvision.ui.theme.SubtleCrimson
import com.rizwan.carromvision.ui.theme.SubtleGold
import com.rizwan.carromvision.ui.theme.TextSecondary

/**
 * Screen 3: Analysis Workspace — displays the normalized screenshot, detected Carrom board,
 * striker, coins, queen, pockets, aiming guidelines, and interactive controls.
 */
@Composable
fun AnalysisWorkspaceScreen(
    state: WorkspaceUiState,
    onBackClick: () -> Unit,
    onImportScreenshotClick: () -> Unit,
    onDetectObjectsClick: () -> Unit,
    onRecalculateClick: () -> Unit,
    onResetClick: () -> Unit,
    onToggleManualAdjustment: () -> Unit,
    onSelectNextTarget: () -> Unit,
    onToggleAlternativeShots: () -> Unit,
    onToggleDirectShots: () -> Unit,
    onToggleBankShots: () -> Unit,
    onTogglePredictedStriker: () -> Unit,
    onBoardTapOrDrag: (Double, Double) -> Unit,
    onReclassifySelectedObject: (ObjectType) -> Unit,
    onOpenDetailedResultsClick: () -> Unit,
    onSaveAnalysisClick: () -> Unit,
    onCyclePracticePreset: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(14.dp)
        ) {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                    Column {
                        Text(
                            text = "Analysis Workspace",
                            style = MaterialTheme.typography.headlineMedium
                        )
                        Text(
                            text = state.statusMessage,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 2
                        )
                    }
                }
                Row {
                    IconButton(onClick = onImportScreenshotClick) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = "Import Image")
                    }
                    IconButton(onClick = onSaveAnalysisClick) {
                        Icon(Icons.Default.Save, contentDescription = "Save to History")
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Interactive Board & Trajectory Canvas Container
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                shape = RoundedCornerShape(16.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    val displayBitmap = state.normalizedBitmap ?: state.sourceBitmap
                    if (displayBitmap != null) {
                        Image(
                            bitmap = displayBitmap.asImageBitmap(),
                            contentDescription = "Normalized Carrom Board",
                            contentScale = ContentScale.FillBounds,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(16.dp))
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(CharcoalCard),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No Screenshot Loaded — Tap 'Import' or 'Practice Preset'",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }

                    // Trajectory & Object Overlay Canvas
                    TrajectoryRenderer.BoardAnalysisCanvas(
                        boardGeometry = state.boardGeometry,
                        detectedObjects = state.detectedObjects,
                        shotSuggestions = state.shotSuggestions,
                        activeShotIndex = state.activeShotIndex,
                        layerConfig = state.guidelineLayers,
                        selectedTargetCoinId = state.selectedTargetCoinId,
                        selectedPocketId = state.selectedPocketId,
                        onNormalizedTapOrDrag = onBoardTapOrDrag,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Detection Summary Telemetry Bar
            val whiteCount = state.detectedObjects.count { it.type == ObjectType.WHITE_COIN }
            val blackCount = state.detectedObjects.count { it.type == ObjectType.BLACK_COIN }
            val queenCount = state.detectedObjects.count { it.type == ObjectType.RED_QUEEN }
            val strikerDetected = state.detectedObjects.any { it.type == ObjectType.STRIKER }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("White: $whiteCount", style = MaterialTheme.typography.bodySmall)
                        Text("Black: $blackCount", style = MaterialTheme.typography.bodySmall)
                        Text(
                            "Queen: ${if (queenCount > 0) "Detected" else "None"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (queenCount > 0) SubtleCrimson else TextSecondary
                        )
                        Text(
                            "Striker: ${if (strikerDetected) "Ready" else "Manual Req."}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (strikerDetected) SubtleGold else SubtleCrimson
                        )
                    }

                    val activeShot = state.primaryShot
                    if (activeShot != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${activeShot.shotType.name.replace('_', ' ')} → ${activeShot.targetPocket.name}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = SubtleGold
                            )
                            Text(
                                text = "Angle: ${"%.1f".format(activeShot.requiredAngleDegrees)}° • Conf: ${"%.0f".format(activeShot.confidenceScore * 100)}%",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Primary Workspace Controls (All 6 Required Buttons)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onDetectObjectsClick,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Detect Objects")
                }
                OutlinedButton(
                    onClick = onRecalculateClick,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Recalculate")
                }
                OutlinedButton(
                    onClick = onResetClick
                ) {
                    Text("Reset")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onToggleManualAdjustment,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Build, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (state.isManualAdjustmentMode) "Done Adjusting" else "Manual Adjust")
                }
                OutlinedButton(
                    onClick = onSelectNextTarget,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Select Target")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Manual Object Reclassification Bar (Visible during Manual Adjustment Mode)
            if (state.isManualAdjustmentMode) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "Manual Calibration Active: Tap/drag any coin on board, or reclassify selected object:",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            ObjectType.entries.filter { it != ObjectType.POCKET }.forEach { type ->
                                FilterChip(
                                    selected = false,
                                    onClick = { onReclassifySelectedObject(type) },
                                    label = { Text(type.name.replace('_', ' ')) }
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Trajectory Layer Toggles
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = state.guidelineLayers.showAlternativeShots,
                    onClick = onToggleAlternativeShots,
                    label = { Text("Show Alternative Shots") }
                )
                FilterChip(
                    selected = state.guidelineLayers.showDirectShots,
                    onClick = onToggleDirectShots,
                    label = { Text("Direct Shots") }
                )
                FilterChip(
                    selected = state.guidelineLayers.showBankShots,
                    onClick = onToggleBankShots,
                    label = { Text("Bank Shots") }
                )
                FilterChip(
                    selected = state.guidelineLayers.showPredictedStrikerPath,
                    onClick = onTogglePredictedStriker,
                    label = { Text("Striker Deflection") }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Bottom Action Row: View Full Analysis Results & Next Practice Board
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onOpenDetailedResultsClick,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = SubtleCrimson)
                ) {
                    Icon(Icons.Default.Visibility, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("View Analysis Results (${state.shotSuggestions.size})")
                }
                OutlinedButton(onClick = onCyclePracticePreset) {
                    Text("Switch Preset")
                }
            }
        }
    }
}
