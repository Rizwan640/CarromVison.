package com.rizwan.carromvision.core.vision

import android.graphics.Bitmap
import android.graphics.Color
import com.rizwan.carromvision.domain.models.DetectedObject
import com.rizwan.carromvision.domain.models.ObjectType
import com.rizwan.carromvision.domain.models.PhysicsConfig
import com.rizwan.carromvision.domain.models.Point2D
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Detects White Coins, Black Coins, and the Red Queen in the perspective-normalized board bitmap.
 * Combines HSV color-space segmentation, connected-component circularity validation,
 * and radius filtering so decorative board markings are never misclassified as the Red Queen.
 */
class CoinDetector {

    fun detectCoins(
        warpedBoardBitmap: Bitmap,
        config: PhysicsConfig
    ): List<DetectedObject> {
        val width = warpedBoardBitmap.width
        val height = warpedBoardBitmap.height
        if (width < 64 || height < 64) return emptyList()

        // Step size for CPU-friendly connected component clustering
        val step = if (width >= 600) 2 else 1
        val gridW = width / step
        val gridH = height / step

        // Pixel classification map: 0 = background/wood, 1 = white coin, 2 = black coin, 3 = red queen
        val labelMap = IntArray(gridW * gridH)
        val hsv = FloatArray(3)

        for (gy in 0 until gridH) {
            val py = gy * step
            val ny = py.toDouble() / height
            for (gx in 0 until gridW) {
                val px = gx * step
                val nx = px.toDouble() / width

                // Exclude corner pocket regions so dark pockets are not mistaken for black coins
                if (isInsideCornerPocketRegion(nx, ny)) continue
                // Exclude outer border margin
                if (nx < 0.045 || nx > 0.955 || ny < 0.045 || ny > 0.955) continue

                val pixel = warpedBoardBitmap.getPixel(px, py)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)
                Color.RGBToHSV(r, g, b, hsv)
                val hue = hsv[0]       // 0..360
                val sat = hsv[1]       // 0..1
                val value = hsv[2]     // 0..1

                val label = when {
                    // Red Queen HSV range: high saturation red/crimson
                    ((hue <= 16f || hue >= 342f) && sat >= 0.58f && value >= 0.45f) -> 3
                    // White Coin HSV range: very high brightness, low saturation
                    (sat <= 0.18f && value >= 0.86f && r >= 215 && g >= 215 && b >= 205) -> 1
                    // Black Coin HSV range: low value/brightness
                    (value in 0.08f..0.28f && r in 20..70 && g in 20..70 && b in 20..75) -> 2
                    else -> 0
                }
                labelMap[gy * gridW + gx] = label
            }
        }

        // Connected-components BFS to extract circular coin candidates
        val visited = BooleanArray(gridW * gridH)
        val candidates = ArrayList<DetectedObject>()
        var coinSeq = 1

        val expectedRadiusNorm = config.defaultCoinRadius
        val minRadiusNorm = expectedRadiusNorm * 0.62
        val maxRadiusNorm = expectedRadiusNorm * 1.32

        val queueX = IntArray(gridW * gridH)
        val queueY = IntArray(gridW * gridH)

        for (gy in 1 until gridH - 1) {
            for (gx in 1 until gridW - 1) {
                val idx = gy * gridW + gx
                val targetLabel = labelMap[idx]
                if (targetLabel == 0 || visited[idx]) continue

                var head = 0
                var tail = 0
                queueX[tail] = gx
                queueY[tail] = gy
                tail++
                visited[idx] = true

                var sumX = 0.0
                var sumY = 0.0
                var minX = gx
                var maxX = gx
                var minY = gy
                var maxY = gy

                while (head < tail) {
                    val cx = queueX[head]
                    val cy = queueY[head]
                    head++

                    sumX += cx
                    sumY += cy
                    if (cx < minX) minX = cx
                    if (cx > maxX) maxX = cx
                    if (cy < minY) minY = cy
                    if (cy > maxY) maxY = cy

                    val neighbors = arrayOf(
                        Pair(cx + 1, cy),
                        Pair(cx - 1, cy),
                        Pair(cx, cy + 1),
                        Pair(cx, cy - 1)
                    )
                    for ((nxGrid, nyGrid) in neighbors) {
                        if (nxGrid in 0 until gridW && nyGrid in 0 until gridH) {
                            val nIdx = nyGrid * gridW + nxGrid
                            if (!visited[nIdx] && labelMap[nIdx] == targetLabel) {
                                visited[nIdx] = true
                                queueX[tail] = nxGrid
                                queueY[tail] = nyGrid
                                tail++
                            }
                        }
                    }
                }

                val pixelCount = tail
                val areaNorm = (pixelCount * step * step).toDouble() / (width.toDouble() * height.toDouble())
                val equivalentRadiusNorm = sqrt(areaNorm / Math.PI)

                // Geometric & circularity validation (rejects thin lines, center rings, and tiny noise)
                val bboxWNorm = ((maxX - minX + 1) * step).toDouble() / width
                val bboxHNorm = ((maxY - minY + 1) * step).toDouble() / height
                val aspectRatio = if (bboxHNorm > 1e-5) bboxWNorm / bboxHNorm else 0.0
                val bboxFillRatio = if (bboxWNorm * bboxHNorm > 1e-6) areaNorm / (bboxWNorm * bboxHNorm) else 0.0

                // Ideal circle inside bounding square has fill ratio π/4 ≈ 0.785
                val isCircular = aspectRatio in 0.68..1.42 && bboxFillRatio in 0.48..0.95
                val isValidCoinSize = equivalentRadiusNorm in minRadiusNorm..maxRadiusNorm

                if (isCircular && isValidCoinSize) {
                    val centerXNorm = ((sumX / pixelCount) * step) / width.toDouble()
                    val centerYNorm = ((sumY / pixelCount) * step) / height.toDouble()

                    val circularityError = kotlin.math.abs(bboxFillRatio - (Math.PI / 4.0))
                    val sizeError = kotlin.math.abs(equivalentRadiusNorm - expectedRadiusNorm) / expectedRadiusNorm
                    val confidence = (1.0 - (circularityError * 0.8 + sizeError * 0.5)).coerceIn(0.55, 0.99)

                    val objType = when (targetLabel) {
                        1 -> ObjectType.WHITE_COIN
                        2 -> ObjectType.BLACK_COIN
                        3 -> ObjectType.RED_QUEEN
                        else -> ObjectType.WHITE_COIN
                    }

                    candidates.add(
                        DetectedObject(
                            id = "${objType.name.lowercase()}_${coinSeq++}",
                            type = objType,
                            x = centerXNorm,
                            y = centerYNorm,
                            radius = equivalentRadiusNorm,
                            confidence = confidence
                        )
                    )
                }
            }
        }

        // Enforce single Red Queen rule: if multiple red candidates exist, keep only the highest confidence coin-sized object
        val queens = candidates.filter { it.type == ObjectType.RED_QUEEN }.sortedByDescending { it.confidence }
        val nonQueens = candidates.filter { it.type != ObjectType.RED_QUEEN }
        val bestQueen = queens.firstOrNull()

        return buildList {
            addAll(nonQueens)
            if (bestQueen != null) add(bestQueen)
        }
    }

    private fun isInsideCornerPocketRegion(nx: Double, ny: Double): Boolean {
        val pockets = listOf(
            Point2D(0.055, 0.055),
            Point2D(0.945, 0.055),
            Point2D(0.945, 0.945),
            Point2D(0.055, 0.945)
        )
        val pt = Point2D(nx, ny)
        return pockets.any { it.distanceTo(pt) <= 0.056 }
    }
}
