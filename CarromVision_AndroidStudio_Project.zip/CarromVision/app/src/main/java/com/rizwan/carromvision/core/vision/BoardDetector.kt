package com.rizwan.carromvision.core.vision

import android.graphics.Bitmap
import android.graphics.Color
import com.rizwan.carromvision.domain.models.BoardGeometry
import com.rizwan.carromvision.domain.models.PhysicsConfig
import com.rizwan.carromvision.domain.models.Point2D
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Independent Computer Vision module for detecting the Carrom board playing surface,
 * four boundary corners, board dimensions, and orientation.
 * Uses OpenCV Canny + contour polygon approximation with a deterministic CPU bitmap
 * luminance/saturation scan fallback when native OpenCV JNI is not initialized in unit tests.
 */
class BoardDetector {

    fun detectBoard(bitmap: Bitmap, config: PhysicsConfig): BoardGeometry {
        val width = bitmap.width
        val height = bitmap.height

        return try {
            detectBoardWithOpenCv(bitmap, config)
        } catch (_: Throwable) {
            detectBoardCpuFallback(bitmap, width, height)
        }
    }

    private fun detectBoardWithOpenCv(bitmap: Bitmap, config: PhysicsConfig): BoardGeometry {
        val srcMat = Mat(bitmap.height, bitmap.width, CvType.CV_8UC4)
        Utils.bitmapToMat(bitmap, srcMat)

        val bgrMat = Mat()
        Imgproc.cvtColor(srcMat, bgrMat, Imgproc.COLOR_RGBA2BGR)

        val hsvMat = Mat()
        Imgproc.cvtColor(bgrMat, hsvMat, Imgproc.COLOR_BGR2HSV)

        val grayMat = Mat()
        Imgproc.cvtColor(bgrMat, grayMat, Imgproc.COLOR_BGR2GRAY)

        // Gaussian blur for noise reduction
        val blurredMat = Mat()
        Imgproc.GaussianBlur(grayMat, blurredMat, Size(5.0, 5.0), 1.4)

        // Canny edge detection
        val edgesMat = Mat()
        Imgproc.Canny(blurredMat, edgesMat, 45.0, 135.0)

        val contours = ArrayList<MatOfPoint>()
        val hierarchy = Mat()
        Imgproc.findContours(
            edgesMat,
            contours,
            hierarchy,
            Imgproc.RETR_EXTERNAL,
            Imgproc.CHAIN_APPROX_SIMPLE
        )

        val minBoardArea = bitmap.width * bitmap.height * 0.20
        var bestQuad: List<Point2D>? = null
        var maxArea = 0.0

        for (contour in contours) {
            val area = Imgproc.contourArea(contour)
            if (area < minBoardArea) continue

            val contour2f = MatOfPoint2f(*contour.toArray())
            val peri = Imgproc.arcLength(contour2f, true)
            val approx = MatOfPoint2f()
            Imgproc.approxPolyDP(contour2f, approx, 0.025 * peri, true)

            if (approx.total() == 4L && area > maxArea) {
                val pts = approx.toArray().map { Point2D(it.x, it.y) }
                val ordered = orderQuadCorners(pts)
                val topW = ordered[0].distanceTo(ordered[1])
                val leftH = ordered[0].distanceTo(ordered[3])
                val aspect = if (leftH > 1.0) topW / leftH else 0.0
                if (aspect in 0.78..1.28) {
                    maxArea = area
                    bestQuad = ordered
                }
            }
            contour2f.release()
            approx.release()
        }

        srcMat.release()
        bgrMat.release()
        hsvMat.release()
        grayMat.release()
        blurredMat.release()
        edgesMat.release()
        hierarchy.release()
        contours.forEach { it.release() }

        if (bestQuad != null) {
            val dx = bestQuad[1].x - bestQuad[0].x
            val dy = bestQuad[1].y - bestQuad[0].y
            val angleDeg = Math.toDegrees(atan2(dy, dx))
            return BoardGeometry(
                topLeftPx = bestQuad[0],
                topRightPx = bestQuad[1],
                bottomRightPx = bestQuad[2],
                bottomLeftPx = bestQuad[3],
                imageWidth = bitmap.width,
                imageHeight = bitmap.height,
                orientationDegrees = angleDeg,
                pockets = BoardGeometry.defaultPockets(),
                detectionConfidence = 0.94
            )
        }

        return detectBoardCpuFallback(bitmap, bitmap.width, bitmap.height)
    }

    /**
     * Deterministic CPU scan that identifies the bright warm wooden Carrom playing surface
     * bounded inside the darker outer frame.
     */
    fun detectBoardCpuFallback(bitmap: Bitmap, width: Int, height: Int): BoardGeometry {
        val centerY = height / 2
        val centerX = width / 2

        var leftEdge = (width * 0.06).toInt()
        var rightEdge = (width * 0.94).toInt()
        var topEdge = (height * 0.06).toInt()
        var bottomEdge = (height * 0.94).toInt()

        // Scan inward from left along midline for playing surface brightness transition
        for (x in 2 until width / 3) {
            if (isPlayingSurfacePixel(bitmap.getPixel(x, centerY))) {
                leftEdge = x
                break
            }
        }
        // Scan inward from right
        for (x in (width - 3) downTo (width * 2 / 3)) {
            if (isPlayingSurfacePixel(bitmap.getPixel(x, centerY))) {
                rightEdge = x
                break
            }
        }
        // Scan inward from top
        for (y in 2 until height / 3) {
            if (isPlayingSurfacePixel(bitmap.getPixel(centerX, y))) {
                topEdge = y
                break
            }
        }
        // Scan inward from bottom
        for (y in (height - 3) downTo (height * 2 / 3)) {
            if (isPlayingSurfacePixel(bitmap.getPixel(centerX, y))) {
                bottomEdge = y
                break
            }
        }

        // Enforce square symmetry if aspect ratio is close to 1:1
        val boardW = (rightEdge - leftEdge).coerceAtLeast(100)
        val boardH = (bottomEdge - topEdge).coerceAtLeast(100)
        val side = min(boardW, boardH)
        val cx = (leftEdge + rightEdge) / 2.0
        val cy = (topEdge + bottomEdge) / 2.0
        val half = side / 2.0

        return BoardGeometry(
            topLeftPx = Point2D(cx - half, cy - half),
            topRightPx = Point2D(cx + half, cy - half),
            bottomRightPx = Point2D(cx + half, cy + half),
            bottomLeftPx = Point2D(cx - half, cy + half),
            imageWidth = width,
            imageHeight = height,
            orientationDegrees = 0.0,
            pockets = BoardGeometry.defaultPockets(),
            detectionConfidence = 0.89
        )
    }

    private fun isPlayingSurfacePixel(pixel: Int): Boolean {
        val r = Color.red(pixel)
        val g = Color.green(pixel)
        val b = Color.blue(pixel)
        // Playing surface is warm wood (high R & G, moderate B) compared to dark wooden frame
        return r > 150 && g > 120 && b > 80 && (r >= g) && (g >= b - 15)
    }

    companion object {
        /**
         * Orders 4 arbitrary quadrilateral corners into [TopLeft, TopRight, BottomRight, BottomLeft].
         */
        fun orderQuadCorners(points: List<Point2D>): List<Point2D> {
            require(points.size == 4) { "Quad ordering requires exactly 4 points." }
            val sortedBySum = points.sortedBy { it.x + it.y }
            val topLeft = sortedBySum.first()
            val bottomRight = sortedBySum.last()

            val remaining = points.filter { it != topLeft && it != bottomRight }
            val (topRight, bottomLeft) = if (remaining.size == 2) {
                if (remaining[0].x - remaining[0].y > remaining[1].x - remaining[1].y) {
                    Pair(remaining[0], remaining[1])
                } else {
                    Pair(remaining[1], remaining[0])
                }
            } else {
                val sortedByDiff = points.sortedBy { it.y - it.x }
                Pair(sortedByDiff.first(), sortedByDiff.last())
            }
            return listOf(topLeft, topRight, bottomRight, bottomLeft)
        }
    }
}
