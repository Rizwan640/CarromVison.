package com.rizwan.carromvision.core.physics

import com.rizwan.carromvision.core.geometry.CoordinateMapper
import com.rizwan.carromvision.domain.models.CollisionPrediction
import com.rizwan.carromvision.domain.models.PhysicsConfig
import com.rizwan.carromvision.domain.models.Point2D
import kotlin.math.abs
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * 2D Rigid-Body Circle-to-Circle Elastic/Inelastic Collision & Momentum Transfer Engine.
 * Implements impulse-momentum equations with configurable mass ratio, restitution, and friction.
 */
class CollisionEngine {

    /**
     * Evaluates the collision between the Striker (at `strikerStartPos` moving toward `ghostBallPos`)
     * and the stationary Target Coin (at `targetCoinCenter`).
     *
     * 2D Impulse-Momentum Equations:
     * Let m_s = strikerMassRatio, m_c = 1.0 (normalized coin mass), e = restitutionCoinCoin.
     * Contact unit normal pointing from Ghost-Ball to Coin:
     *   n = normalize(C_coin - C_ghost)
     * Unit tangent vector:
     *   t = (-n_y, n_x)
     * Incoming striker velocity before impact:
     *   v_s0 = u_approach * v_impact
     * Since coin is initially at rest (v_c0 = 0):
     * Normal scalar velocity of striker before impact: v_sn = v_s0 · n
     * Tangential scalar velocity of striker before impact: v_st = v_s0 · t
     *
     * Post-collision normal velocities:
     *   v_sn' = ((m_s - e * m_c) / (m_s + m_c)) * v_sn
     *   v_cn' = ((1 + e) * m_s / (m_s + m_c)) * v_sn
     * Post-collision velocity vectors:
     *   v_s' = v_sn' * n + v_st * t
     *   v_c' = v_cn' * n
     */
    fun predictCollision(
        strikerStartPos: Point2D,
        ghostBallPos: Point2D,
        targetCoinCenter: Point2D,
        desiredTargetMovePoint: Point2D,
        coinRadius: Double,
        strikerRadius: Double,
        config: PhysicsConfig
    ): CollisionPrediction {
        val approachDistance = strikerStartPos.distanceTo(ghostBallPos)
        val approachDir = (ghostBallPos - strikerStartPos).normalized()

        // Account for sliding friction deceleration prior to impact: v_impact^2 = v_0^2 - 2 * mu * g_norm * d
        val v0Sq = config.initialVelocity * config.initialVelocity
        val preImpactEnergyLoss = 2.0 * config.frictionCoefficient * approachDistance * 0.45
        val impactSpeed = sqrt((v0Sq - preImpactEnergyLoss).coerceAtLeast(0.25))
        val strikerPreVel = approachDir * impactSpeed

        val contactNormal = (targetCoinCenter - ghostBallPos).normalized()
        val contactTangent = Point2D(-contactNormal.y, contactNormal.x)

        val vSn = strikerPreVel.dot(contactNormal)
        val vSt = strikerPreVel.dot(contactTangent)

        val mS = config.strikerMassRatio
        val mC = 1.0
        val e = config.restitutionCoinCoin

        val postStrikerNormalSpeed = ((mS - e * mC) / (mS + mC)) * vSn * config.collisionDamping
        val postCoinNormalSpeed = (((1.0 + e) * mS) / (mS + mC)) * vSn * config.collisionDamping

        val strikerPostVel = (contactNormal * postStrikerNormalSpeed) + (contactTangent * (vSt * config.collisionDamping))
        val coinPostVel = contactNormal * postCoinNormalSpeed

        // Stopping distance under Coulomb sliding friction: d_stop = v^2 / (2 * mu_effective)
        val muEff = (config.frictionCoefficient * 1.35).coerceAtLeast(0.05)

        val strikerPostSpeed = sqrt(strikerPostVel.dot(strikerPostVel))
        val strikerStopDist = ((strikerPostSpeed * strikerPostSpeed) / (2.0 * muEff)).coerceAtMost(0.85)
        val rawStrikerFinal = ghostBallPos + (strikerPostVel.normalized() * strikerStopDist)
        val clampedStrikerFinal = Point2D(
            x = rawStrikerFinal.x.coerceIn(strikerRadius, 1.0 - strikerRadius),
            y = rawStrikerFinal.y.coerceIn(strikerRadius, 1.0 - strikerRadius)
        )

        val coinPostSpeed = sqrt(coinPostVel.dot(coinPostVel))
        val coinStopDist = ((coinPostSpeed * coinPostSpeed) / (2.0 * muEff)).coerceAtMost(1.40)
        val rawCoinFinal = targetCoinCenter + (coinPostVel.normalized() * coinStopDist)
        val clampedCoinFinal = Point2D(
            x = rawCoinFinal.x.coerceIn(coinRadius, 1.0 - coinRadius),
            y = rawCoinFinal.y.coerceIn(coinRadius, 1.0 - coinRadius)
        )

        val impactPoint = CoordinateMapper.calculateSurfaceImpactPoint(
            targetCoinCenter = targetCoinCenter,
            desiredTargetMovePoint = desiredTargetMovePoint,
            coinRadius = coinRadius
        )

        val cutAngleDeg = CoordinateMapper.calculateCutAngleDegrees(
            strikerPos = strikerStartPos,
            ghostBallPos = ghostBallPos,
            targetCoinPos = targetCoinCenter,
            desiredTargetMovePoint = desiredTargetMovePoint
        )
        // Collision-induced throw angle correction due to brief inter-coin friction during oblique impact
        val throwCorrectionDeg = 0.045 * sin(Math.toRadians(cutAngleDeg * 2.0)) * 18.0

        val energyTransferRatio = if (impactSpeed > 1e-6) {
            (coinPostSpeed / impactSpeed).coerceIn(0.0, 1.5)
        } else {
            0.0
        }

        return CollisionPrediction(
            impactPoint = impactPoint,
            contactNormal = contactNormal,
            strikerPostVelocity = strikerPostVel,
            coinPostVelocity = coinPostVel,
            estimatedStrikerFinalPos = clampedStrikerFinal,
            estimatedCoinFinalPos = clampedCoinFinal,
            energyTransferRatio = energyTransferRatio,
            throwAngleCorrectionDeg = throwCorrectionDeg
        )
    }

    /**
     * Exact analytical Ray-Circle intersection test to detect whether a moving circle of radius `r1`
     * starting at `p1` along `dir` collides with a stationary circle of radius `r2` at `p2`.
     * Returns the distance along `dir` to impact, or null if no collision occurs.
     */
    fun computeCircleCollisionDistance(
        p1: Point2D,
        dir: Point2D,
        r1: Double,
        p2: Point2D,
        r2: Double
    ): Double? {
        val u = dir.normalized()
        val combinedRadius = r1 + r2
        val f = p1 - p2

        val b = 2.0 * f.dot(u)
        val c = f.dot(f) - combinedRadius * combinedRadius
        val discriminant = b * b - 4.0 * c

        if (discriminant < 0.0) return null
        val sqrtDisc = sqrt(discriminant)
        val t1 = (-b - sqrtDisc) / 2.0
        val t2 = (-b + sqrtDisc) / 2.0

        return when {
            t1 >= 0.0 -> t1
            t2 >= 0.0 -> 0.0
            else -> null
        }
    }
}
