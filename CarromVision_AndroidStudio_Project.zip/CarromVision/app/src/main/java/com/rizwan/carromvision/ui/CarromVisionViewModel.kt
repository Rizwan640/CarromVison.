package com.rizwan.carromvision.ui

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.rizwan.carromvision.calibration.CalibrationManager
import com.rizwan.carromvision.calibration.CalibrationProfile
import com.rizwan.carromvision.capture.CaptureStatus
import com.rizwan.carromvision.capture.ScreenCaptureManager
import com.rizwan.carromvision.data.database.AnalysisEntity
import com.rizwan.carromvision.data.preferences.AppPreferences
import com.rizwan.carromvision.data.preferences.UserPreferencesRepository
import com.rizwan.carromvision.data.repository.AnalysisRepository
import com.rizwan.carromvision.domain.models.BoardGeometry
import com.rizwan.carromvision.domain.models.DetectedObject
import com.rizwan.carromvision.domain.models.GuidelineLayerConfig
import com.rizwan.carromvision.domain.models.ObjectType
import com.rizwan.carromvision.domain.models.PhysicsConfig
import com.rizwan.carromvision.domain.models.Point2D
import com.rizwan.carromvision.domain.models.ShotSuggestion
import com.rizwan.carromvision.domain.usecases.AnalyzeBoardUseCase
import com.rizwan.carromvision.utils.PracticeBoardGenerator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class WorkspaceUiState(
    val sourceBitmap: Bitmap? = null,
    val normalizedBitmap: Bitmap? = null,
    val boardGeometry: BoardGeometry? = null,
    val detectedObjects: List<DetectedObject> = emptyList(),
    val shotSuggestions: List<ShotSuggestion> = emptyList(),
    val activeShotIndex: Int = 0,
    val selectedTargetCoinId: String? = null,
    val selectedPocketId: Int? = null,
    val isManualAdjustmentMode: Boolean = false,
    val selectedObjectForEditId: String? = null,
    val guidelineLayers: GuidelineLayerConfig = GuidelineLayerConfig(),
    val requiresUserConfirmation: Boolean = false,
    val isProcessing: Boolean = false,
    val statusMessage: String = "Import a Carrom Pool screenshot or load Practice Mode to begin.",
    val practicePresetIndex: Int = 0
) {
    val primaryShot: ShotSuggestion?
        get() = shotSuggestions.getOrNull(activeShotIndex)
}

class CarromVisionViewModel(
    private val preferencesRepository: UserPreferencesRepository,
    private val analysisRepository: AnalysisRepository,
    private val screenCaptureManager: ScreenCaptureManager,
    private val calibrationManager: CalibrationManager = CalibrationManager(),
    private val analyzeBoardUseCase: AnalyzeBoardUseCase = AnalyzeBoardUseCase()
) : ViewModel() {

    val appPreferences: StateFlow<AppPreferences> = preferencesRepository.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppPreferences())

    val historyList: StateFlow<List<AnalysisEntity>> = analysisRepository.allAnalyses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val captureStatus: StateFlow<CaptureStatus> = screenCaptureManager.status

    private val _workspaceState = MutableStateFlow(WorkspaceUiState())
    val workspaceState: StateFlow<WorkspaceUiState> = _workspaceState.asStateFlow()

    fun loadPracticeBoard(nextPreset: Boolean = false) {
        val nextIdx = if (nextPreset) _workspaceState.value.practicePresetIndex + 1 else _workspaceState.value.practicePresetIndex
        val bitmap = PracticeBoardGenerator.createPracticeBitmap(800, 800, nextIdx)
        _workspaceState.value = _workspaceState.value.copy(
            sourceBitmap = bitmap,
            practicePresetIndex = nextIdx,
            selectedTargetCoinId = null,
            selectedPocketId = null,
            activeShotIndex = 0
        )
        detectObjectsOnCurrentBitmap()
    }

    fun onScreenshotImported(bitmap: Bitmap) {
        _workspaceState.value = _workspaceState.value.copy(
            sourceBitmap = bitmap,
            selectedTargetCoinId = null,
            selectedPocketId = null,
            activeShotIndex = 0
        )
        detectObjectsOnCurrentBitmap()
    }

    fun detectObjectsOnCurrentBitmap() {
        val bmp = _workspaceState.value.sourceBitmap ?: return
        viewModelScope.launch {
            _workspaceState.value = _workspaceState.value.copy(
                isProcessing = true,
                statusMessage = "Running OpenCV board, pocket, coin, and striker detection..."
            )
            val prefs = appPreferences.value
            val calProfile = calibrationManager.deserializeProfile(prefs.activeCalibrationProfileJson)
            val result = analyzeBoardUseCase.execute(
                sourceBitmap = bmp,
                physicsConfig = prefs.physicsConfig,
                calibrationProfile = calProfile,
                selectedTargetId = _workspaceState.value.selectedTargetCoinId,
                selectedPocketId = _workspaceState.value.selectedPocketId
            )
            _workspaceState.value = _workspaceState.value.copy(
                normalizedBitmap = result.normalizedBoardBitmap,
                boardGeometry = result.boardGeometry,
                detectedObjects = result.detectedObjects,
                shotSuggestions = result.shotSuggestions,
                activeShotIndex = 0,
                requiresUserConfirmation = result.requiresUserConfirmation,
                isProcessing = false,
                statusMessage = result.statusMessage
            )
        }
    }

    fun recalculateTrajectories() {
        val current = _workspaceState.value
        val normBmp = current.normalizedBitmap ?: return
        val geom = current.boardGeometry ?: return
        viewModelScope.launch {
            _workspaceState.value = current.copy(isProcessing = true)
            val shots = analyzeBoardUseCase.recalculateFromObjects(
                normalizedBoardBitmap = normBmp,
                boardGeometry = geom,
                detectedObjects = current.detectedObjects,
                physicsConfig = appPreferences.value.physicsConfig,
                selectedTargetId = current.selectedTargetCoinId,
                selectedPocketId = current.selectedPocketId
            )
            _workspaceState.value = _workspaceState.value.copy(
                shotSuggestions = shots,
                activeShotIndex = 0,
                isProcessing = false,
                statusMessage = "Recalculated ${shots.size} candidate trajectories."
            )
        }
    }

    fun resetWorkspace() {
        val bmp = _workspaceState.value.sourceBitmap
        if (bmp != null) {
            _workspaceState.value = _workspaceState.value.copy(
                selectedTargetCoinId = null,
                selectedPocketId = null,
                activeShotIndex = 0,
                isManualAdjustmentMode = false,
                selectedObjectForEditId = null
            )
            detectObjectsOnCurrentBitmap()
        }
    }

    fun selectTargetCoin(coinId: String?) {
        _workspaceState.value = _workspaceState.value.copy(selectedTargetCoinId = coinId)
        recalculateTrajectories()
    }

    fun selectTargetPocket(pocketId: Int?) {
        _workspaceState.value = _workspaceState.value.copy(selectedPocketId = pocketId)
        recalculateTrajectories()
    }

    fun selectShotIndex(index: Int) {
        val validIdx = index.coerceIn(0, (_workspaceState.value.shotSuggestions.size - 1).coerceAtLeast(0))
        _workspaceState.value = _workspaceState.value.copy(activeShotIndex = validIdx)
    }

    fun toggleManualAdjustmentMode() {
        val nextMode = !_workspaceState.value.isManualAdjustmentMode
        _workspaceState.value = _workspaceState.value.copy(
            isManualAdjustmentMode = nextMode,
            statusMessage = if (nextMode) {
                "Manual Adjustment Active: Tap or drag any coin/striker on the board to refine position."
            } else {
                "Manual Adjustment Closed. Trajectories updated."
            }
        )
    }

    fun onBoardTapOrDragNormalized(normX: Double, normY: Double) {
        val current = _workspaceState.value
        val tapPoint = Point2D(normX.coerceIn(0.03, 0.97), normY.coerceIn(0.03, 0.97))

        if (current.isManualAdjustmentMode) {
            // Find nearest object within 0.08 normalized distance or move selected object
            val targetObj = current.detectedObjects.minByOrNull { it.center.distanceTo(tapPoint) }
            if (targetObj != null && targetObj.center.distanceTo(tapPoint) <= 0.12) {
                val updated = calibrationManager.adjustObjectPosition(
                    objects = current.detectedObjects,
                    objectId = targetObj.id,
                    newX = tapPoint.x,
                    newY = tapPoint.y
                )
                _workspaceState.value = current.copy(
                    detectedObjects = updated,
                    selectedObjectForEditId = targetObj.id,
                    requiresUserConfirmation = false
                )
                recalculateTrajectories()
            }
        } else {
            // Target selection mode: check if user tapped a pocket or a coin
            val geom = current.boardGeometry
            val tappedPocket = geom?.pockets?.minByOrNull { it.center.distanceTo(tapPoint) }
            if (tappedPocket != null && tappedPocket.center.distanceTo(tapPoint) <= 0.07) {
                selectTargetPocket(tappedPocket.id)
                return
            }

            val tappedCoin = current.detectedObjects
                .filter { it.type != ObjectType.STRIKER }
                .minByOrNull { it.center.distanceTo(tapPoint) }

            if (tappedCoin != null && tappedCoin.center.distanceTo(tapPoint) <= 0.065) {
                selectTargetCoin(tappedCoin.id)
            }
        }
    }

    fun reclassifySelectedObject(newType: ObjectType) {
        val current = _workspaceState.value
        val objId = current.selectedObjectForEditId ?: return
        val updated = calibrationManager.reclassifyObject(current.detectedObjects, objId, newType)
        _workspaceState.value = current.copy(detectedObjects = updated)
        recalculateTrajectories()
    }

    fun toggleGuidelineLayer(updater: (GuidelineLayerConfig) -> GuidelineLayerConfig) {
        val updatedLayers = updater(_workspaceState.value.guidelineLayers)
        _workspaceState.value = _workspaceState.value.copy(guidelineLayers = updatedLayers)
    }

    fun saveCurrentAnalysisToHistory(notes: String = "Saved from Carrom Vision Workspace") {
        val current = _workspaceState.value
        val shot = current.primaryShot ?: return
        viewModelScope.launch {
            analysisRepository.saveAnalysis(
                screenshotUri = null,
                retainScreenshot = appPreferences.value.retainScreenshotsInHistory,
                detectedObjects = current.detectedObjects,
                selectedShot = shot,
                notes = notes
            )
            _workspaceState.value = current.copy(
                statusMessage = "Analysis saved to local Room database history."
            )
        }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch {
            analysisRepository.deleteAnalysis(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            analysisRepository.clearAllHistory()
        }
    }

    fun updatePhysicsConfig(newConfig: PhysicsConfig) {
        viewModelScope.launch {
            preferencesRepository.updatePhysicsConfig(newConfig)
            recalculateTrajectories()
        }
    }

    fun updateRetainScreenshots(retain: Boolean) {
        viewModelScope.launch {
            preferencesRepository.updatePrivacyRetainScreenshots(retain)
        }
    }

    fun updateAccentTheme(theme: String) {
        viewModelScope.launch {
            preferencesRepository.updateAccentTheme(theme)
        }
    }

    fun saveManualCalibrationProfile(profile: CalibrationProfile) {
        viewModelScope.launch {
            calibrationManager.setActiveProfile(profile)
            preferencesRepository.saveCalibrationProfileJson(calibrationManager.serializeProfile(profile))
            detectObjectsOnCurrentBitmap()
        }
    }

    class Factory(
        private val preferencesRepository: UserPreferencesRepository,
        private val analysisRepository: AnalysisRepository,
        private val screenCaptureManager: ScreenCaptureManager
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return CarromVisionViewModel(
                preferencesRepository = preferencesRepository,
                analysisRepository = analysisRepository,
                screenCaptureManager = screenCaptureManager
            ) as T
        }
    }
}
