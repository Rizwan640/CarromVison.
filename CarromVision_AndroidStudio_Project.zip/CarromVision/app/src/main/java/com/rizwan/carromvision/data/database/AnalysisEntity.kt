package com.rizwan.carromvision.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "analysis_history")
data class AnalysisEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val timestampMillis: Long,
    val screenshotUri: String?,
    val detectedObjectsJson: String,
    val selectedTargetId: String,
    val selectedTargetType: String,
    val selectedPocketId: Int,
    val selectedPocketName: String,
    val calculatedShotAngleDeg: Double,
    val shotType: String,
    val confidenceScore: Double,
    val trajectoryJson: String,
    val userNotes: String
)
