package com.rizwan.carromvision.core.physics

import com.rizwan.carromvision.domain.models.PhysicsConfig
import com.rizwan.carromvision.domain.models.Pocket
import com.rizwan.carromvision.domain.models.Point2D
import com.rizwan.carromvision.domain.models.TrajectorySegment
import kotlin.math.abs

/**
 * Represents the 4 inner cushions of the normalized Carrom board [0.0, 1.0].
 */
enum class CushionWall(val index: Int, val label: String) {
    LEFT(0, "Left Cushion"),
    RIGHT(1, "Right Cushion"),
    TOP(2, "Top Cushion"),
    BOTTOM(3, "Bottom Cushion")
}

data class BankShotPath(
    val cushionSequence: List<CushionWall>,
    val firstBouncePoint: Point2D,
    val segments: List<TrajectorySegment>,
    val totalPathLength: Double
)

/**
 * Geometric Mirror-Image Cushion Reflection Engine for Single and Double Bank Shots.
 * Accounts for finite coin radius (`r`) so cushion reflection occurs along the effective inner
 * rail boundary: `x_min = r`, `x_max = 1 - r`, `y_min = r`, `y_max = 1 - r`.
 * Also applies inelastic cushion restitution adjustment (`restitutionCushion`).
 */
class CushionReflectionEngine {

    /**
     * Mirrors a 2D point across the specified cushion wall, accounting for finite object radius `radius`.
     */
    fun mirrorPointAcrossCushion(
        point: Point2D,
        wall: CushionWall,
        radius: Double
    ): Point2D {
        val minBound = radius.coerceIn(0.01, 0.10)
        val maxBound = (1.0 - minBound).coerceIn(0.90, 0.99)
        return when (wall) {
            CushionWall.LEFT -> Point2D(2.0 * minBound - point.x, point.y)
            CushionWall.RIGHT -> Point2D(2.0 * maxBound - point.x, point.y)
            CushionWall.TOP -> Point2D(point.x, 2.0 * minBound - point.y)
            CushionWall.BOTTOM -> Point2D(point.x, 2.0 * maxBound - point.y)
        }
    }

    /**
     * Calculates all valid Single-Cushion bank shot paths from `startPoint` (Target Coin or Striker)
     * into `targetPocket`.
     */
    fun calculateSingleCushionPaths(
        startPoint: Point2D,
        targetPocket: Pocket,
        objectRadius: Double,
        config: PhysicsConfig
    ): List<BankShotPath> {
        val minBound = objectRadius.coerceIn(0.02, 0.06)
        val maxBound = 1.0 - minBound
        val results = ArrayList<BankShotPath>()

        for (wall in CushionWall.entries) {
            val mirroredPocket = mirrorPointAcrossCushion(targetPocket.center, wall, minBound)
            val bouncePoint = computeWallIntersection(startPoint, mirroredPocket, wall, minBound, maxBound)
                ?: continue

            // Validate that bouncePoint lies strictly within the legal playing rail and away from corner pockets
            if (!isValidRailBouncePoint(bouncePoint, wall, minBound, maxBound)) continue

            // Validate that startPoint and targetPocket are on the interior side of the cushion
            val seg1 = TrajectorySegment(
                start = startPoint,
                end = bouncePoint,
                isCushionRebound = false,
                cushionIndex = wall.index
            )
            val seg2 = TrajectorySegment(
                start = bouncePoint,
                end = targetPocket.center,
                isCushionRebound = true,
                cushionIndex = wall.index
            )
            val totalLen = seg1.start.distanceTo(seg1.end) + seg2.start.distanceTo(seg2.end)

            results.add(
                BankShotPath(
                    cushionSequence = listOf(wall),
                    firstBouncePoint = bouncePoint,
                    segments = listOf(seg1, seg2),
                    totalPathLength = totalLen
                )
            )
        }

        return results
    }

    /**
     * Calculates valid Double-Cushion bank shot paths from `startPoint` to `targetPocket`
     * via pairs of cushions `(wall1, wall2)`.
     */
    fun calculateDoubleCushionPaths(
        startPoint: Point2D,
        targetPocket: Pocket,
        objectRadius: Double,
        config: PhysicsConfig
    ): List<BankShotPath> {
        val minBound = objectRadius.coerceIn(0.02, 0.06)
        val maxBound = 1.0 - minBound
        val results = ArrayList<BankShotPath>()

        val candidatePairs = listOf(
            Pair(CushionWall.LEFT, CushionWall.RIGHT),
            Pair(CushionWall.RIGHT, CushionWall.LEFT),
            Pair(CushionWall.TOP, CushionWall.BOTTOM),
            Pair(CushionWall.BOTTOM, CushionWall.TOP),
            Pair(CushionWall.LEFT, CushionWall.TOP),
            Pair(CushionWall.RIGHT, CushionWall.TOP),
            Pair(CushionWall.LEFT, CushionWall.BOTTOM),
            Pair(CushionWall.RIGHT, CushionWall.BOTTOM)
        )

        for ((wall1, wall2) in candidatePairs) {
            // 1. Mirror pocket across second wall (wall2), then mirror that image across first wall (wall1)
            val mirror1 = mirrorPointAcrossCushion(targetPocket.center, wall2, minBound)
            val mirror2 = mirrorPointAcrossCushion(mirror1, wall1, minBound)

            // 2. Intersect ray from startPoint -> mirror2 with wall1 to get first bounce point B1
            val bounce1 = computeWallIntersection(startPoint, mirror2, wall1, minBound, maxBound)
                ?: continue
            if (!isValidRailBouncePoint(bounce1, wall1, minBound, maxBound)) continue

            // 3. Intersect ray from bounce1 -> mirror1 with wall2 to get second bounce point B2
            val bounce2 = computeWallIntersection(bounce1, mirror1, wall2, minBound, maxBound)
                ?: continue
            if (!isValidRailBouncePoint(bounce2, wall2, minBound, maxBound)) continue

            val seg1 = TrajectorySegment(startPoint, bounce1, isCushionRebound = false, cushionIndex = wall1.index)
            val seg2 = TrajectorySegment(bounce1, bounce2, isCushionRebound = true, cushionIndex = wall2.index)
            val seg3 = TrajectorySegment(bounce2, targetPocket.center, isCushionRebound = true, cushionIndex = wall2.index)

            val totalLen = seg1.start.distanceTo(seg1.end) +
                seg2.start.distanceTo(seg2.end) +
                seg3.start.distanceTo(seg3.end)

            if (totalLen <= 2.45) {
                results.add(
                    BankShotPath(
                        cushionSequence = listOf(wall1, wall2),
                        firstBouncePoint = bounce1,
                        segments = listOf(seg1, seg2, seg3),
                        totalPathLength = totalLen
                    )
                )
            }
        }

        return results
    }

    private fun computeWallIntersection(
        from: Point2D,
        toMirrored: Point2D,
        wall: CushionWall,
        minBound: Double,
        maxBound: Double
    ): Point2D? {
        val dx = toMirrored.x - from.x
        val dy = toMirrored.y - from.y

        return when (wall) {
            CushionWall.LEFT -> {
                if (abs(dx) < 1e-7) return null
                val t = (minBound - from.x) / dx
                if (t <= 0.0 || t >= 1.0) return null
                Point2D(minBound, from.y + t * dy)
            }
            CushionWall.RIGHT -> {
                if (abs(dx) < 1e-7) return null
                val t = (maxBound - from.x) / dx
                if (t <= 0.0 || t >= 1.0) return null
                Point2D(maxBound, from.y + t * dy)
            }
            CushionWall.TOP -> {
                if (abs(dy) < 1e-7) return null
                val t = (minBound - from.y) / dy
                if (t <= 0.0 || t >= 1.0) return null
                Point2D(from.x + t * dx, minBound)
            }
            CushionWall.BOTTOM -> {
                if (abs(dy) < 1e-7) return null
                val t = (maxBound - from.y) / dy
                if (t <= 0.0 || t >= 1.0) return null
                Point2D(from.x + t * dx, maxBound)
            }
        }
    }

    private fun isValidRailBouncePoint(
        pt: Point2D,
        wall: CushionWall,
        minBound: Double,
        maxBound: Double
    ): Boolean {
        // Cushion rails stop short of the corner pockets (pockets occupy 0.0..0.10 and 0.90..1.0)
        val railMin = 0.11
        val railMax = 0.89
        return when (wall) {
            CushionWall.LEFT, CushionWall.RIGHT -> pt.y in railMin..railMax && pt.x in (minBound - 0.005)..(maxBound + 0.005)
            CushionWall.TOP, CushionWall.BOTTOM -> pt.x in railMin..railMax && pt.y in (minBound - 0.005)..(maxBound + 0.005)
        }
    }
}
