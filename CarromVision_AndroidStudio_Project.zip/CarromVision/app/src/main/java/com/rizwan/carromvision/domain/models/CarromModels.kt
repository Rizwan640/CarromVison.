package com.rizwan.carromvision.domain.models

import kotlin.math.sqrt

/**
 * Classification of detected Carrom objects on the playing surface.
 */
enum class ObjectType {
    WHITE_COIN,
    BLACK_COIN,
    RED_QUEEN,
    STRIKER,
    POCKET
}

/**
 * Classification of calculated shot types.
 */
enum class ShotType {
    DIRECT_SHOT,
    SINGLE_BANK_SHOT,
    DOUBLE_BANK_SHOT,
    COLLISION_ASSIST_SHOT
}

/**
 * 2D point in normalized board coordinates [0.0, 1.0] or pixel coordinates.
 */
data class Point2D(
    val x: Double,
    val y: Double
) {
    fun distanceTo(other: Point2D): Double {
        val dx = other.x - x
        val dy = other.y - y
        return sqrt(dx * dx + dy * dy)
    }

    operator fun plus(other: Point2D) = Point2D(x + other.x, y + other.y)
    operator fun minus(other: Point2D) = Point2D(x - other.x, y - other.y)
    operator fun times(scalar: Double) = Point2D(x * scalar, y * scalar)

    fun normalized(): Point2D {
        val len = sqrt(x * x + y * y)
        return if (len > 1e-9) Point2D(x / len, y / len) else Point2D(0.0, 0.0)
    }

    fun dot(other: Point2D): Double = x * other.x + y * other.y
}

/**
 * Represents a single detected Carrom object in normalized board coordinates (0.0 .. 1.0).
 */
data class DetectedObject(
    val id: String,
    val type: ObjectType,
    val x: Double,
    val y: Double,
    val radius: Double,
    val confidence: Double,
    val isManuallyAdjusted: Boolean = false
) {
    val center: Point2D get() = Point2D(x, y)
}

/**
 * Represents one of the four corner pockets in normalized coordinates.
 */
data class Pocket(
    val id: Int,
    val name: String,
    val x: Double,
    val y: Double,
    val radius: Double = 0.042
) {
    val center: Point2D get() = Point2D(x, y)
}

/**
 * Represents the detected Carrom board boundary in original image pixel coordinates
 * as well as normalized geometry metadata.
 */
data class BoardGeometry(
    val topLeftPx: Point2D,
    val topRightPx: Point2D,
    val bottomRightPx: Point2D,
    val bottomLeftPx: Point2D,
    val imageWidth: Int,
    val imageHeight: Int,
    val orientationDegrees: Double = 0.0,
    val pockets: List<Pocket> = defaultPockets(),
    val detectionConfidence: Double = 1.0
) {
    companion object {
        fun defaultPockets(): List<Pocket> = listOf(
            Pocket(0, "Top-Left Pocket", 0.055, 0.055, 0.042),
            Pocket(1, "Top-Right Pocket", 0.945, 0.055, 0.042),
            Pocket(2, "Bottom-Right Pocket", 0.945, 0.945, 0.042),
            Pocket(3, "Bottom-Left Pocket", 0.055, 0.945, 0.042)
        )
    }
}

/**
 * Configurable physical constants for Carrom simulation and trajectory calculation.
 */
data class PhysicsConfig(
    val initialVelocity: Double = 1.65,
    val frictionCoefficient: Double = 0.18,
    val restitutionCoinCoin: Double = 0.88,
    val restitutionCushion: Double = 0.78,
    val collisionDamping: Double = 0.92,
    val strikerMassRatio: Double = 1.85,
    val defaultCoinRadius: Double = 0.029,
    val defaultStrikerRadius: Double = 0.038,
    val defaultPocketRadius: Double = 0.042,
    val cpuFriendlyMode: Boolean = true,
    val maxProcessingResolution: Int = 960,
    val detectionSensitivity: Double = 0.65
)

/**
 * Represents a segment of a trajectory path in normalized coordinates.
 */
data class TrajectorySegment(
    val start: Point2D,
    val end: Point2D,
    val isCushionRebound: Boolean = false,
    val cushionIndex: Int = -1
)

/**
 * Represents a predicted collision between two circular bodies.
 */
data class CollisionPrediction(
    val impactPoint: Point2D,
    val contactNormal: Point2D,
    val strikerPostVelocity: Point2D,
    val coinPostVelocity: Point2D,
    val estimatedStrikerFinalPos: Point2D,
    val estimatedCoinFinalPos: Point2D,
    val energyTransferRatio: Double,
    val throwAngleCorrectionDeg: Double = 0.0
)

/**
 * Represents a complete evaluated shot option produced by ShotAnalyzer & ShotRankingEngine.
 */
data class ShotSuggestion(
    val id: String,
    val shotType: ShotType,
    val targetCoin: DetectedObject,
    val targetPocket: Pocket,
    val strikerStartPos: Point2D,
    val requiredContactPoint: Point2D,
    val requiredAngleDegrees: Double,
    val cutAngleDegrees: Double,
    val strikerPath: List<TrajectorySegment>,
    val coinPath: List<TrajectorySegment>,
    val strikerPostCollisionPath: List<TrajectorySegment>,
    val collisionPrediction: CollisionPrediction,
    val obstaclesOnPath: List<DetectedObject>,
    val cushionCount: Int,
    val estimatedStrikerFinalPos: Point2D,
    val confidenceScore: Double,
    val isUncertain: Boolean,
    val summaryNote: String
)

/**
 * Layer visibility toggles for Aiming Guideline Rendering.
 */
data class GuidelineLayerConfig(
    val showDirectShots: Boolean = true,
    val showBankShots: Boolean = true,
    val showCollisionPaths: Boolean = true,
    val showPredictedStrikerPath: Boolean = true,
    val showUncertainPredictions: Boolean = true,
    val showAlternativeShots: Boolean = false,
    val showPocketZones: Boolean = true
)
