package com.rizwan.carromvision

import com.rizwan.carromvision.core.geometry.CoordinateMapper
import com.rizwan.carromvision.core.physics.CollisionEngine
import com.rizwan.carromvision.core.physics.CushionReflectionEngine
import com.rizwan.carromvision.core.physics.CushionWall
import com.rizwan.carromvision.core.physics.TrajectoryEngine
import com.rizwan.carromvision.core.vision.BoardDetector
import com.rizwan.carromvision.core.vision.PerspectiveTransformer
import com.rizwan.carromvision.domain.algorithms.ShotAnalyzer
import com.rizwan.carromvision.domain.algorithms.ShotRankingEngine
import com.rizwan.carromvision.domain.models.BoardGeometry
import com.rizwan.carromvision.domain.models.DetectedObject
import com.rizwan.carromvision.domain.models.ObjectType
import com.rizwan.carromvision.domain.models.PhysicsConfig
import com.rizwan.carromvision.domain.models.Pocket
import com.rizwan.carromvision.domain.models.Point2D
import com.rizwan.carromvision.domain.models.ShotType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Comprehensive JUnit4 Test Suite covering all 11 required unit test categories:
 * 1. Coordinate transformations
 * 2. Circle / radius geometry
 * 3. Board boundary ordering & calculations
 * 4. Pocket geometry
 * 5. Distance calculations
 * 6. Shot angle calculations
 * 7. Collision geometry & momentum transfer
 * 8. Cushion reflection (Single & Double bank shots)
 * 9. Trajectory calculations with sliding friction
 * 10. Obstacle detection along segments
 * 11. Shot ranking & confidence scoring caps
 */
class CarromEngineUnitTests {

    private val defaultConfig = PhysicsConfig()
    private val collisionEngine = CollisionEngine()
    private val cushionEngine = CushionReflectionEngine()
    private val trajectoryEngine = TrajectoryEngine()
    private val rankingEngine = ShotRankingEngine()
    private val shotAnalyzer = ShotAnalyzer()

    @Test
    fun testCoordinateTransformationsRoundTrip() {
        val norm = CoordinateMapper.pixelToNormalized(
            pixelX = 440.0,
            pixelY = 260.0,
            boardLeftPx = 40.0,
            boardTopPx = 60.0,
            boardWidthPx = 800.0,
            boardHeightPx = 800.0
        )
        assertEquals(0.50, norm.x, 1e-6)
        assertEquals(0.25, norm.y, 1e-6)

        val pixel = CoordinateMapper.normalizedToPixel(
            normPoint = norm,
            boardLeftPx = 40.0,
            boardTopPx = 60.0,
            boardWidthPx = 800.0,
            boardHeightPx = 800.0
        )
        assertEquals(440.0, pixel.x, 1e-5)
        assertEquals(260.0, pixel.y, 1e-5)
    }

    @Test
    fun testBoardBoundaryQuadCornerOrdering() {
        val unordered = listOf(
            Point2D(752.0, 752.0), // Bottom-Right
            Point2D(48.0, 752.0),  // Bottom-Left
            Point2D(752.0, 48.0),  // Top-Right
            Point2D(48.0, 48.0)    // Top-Left
        )
        val ordered = BoardDetector.orderQuadCorners(unordered)
        assertEquals(Point2D(48.0, 48.0), ordered[0])
        assertEquals(Point2D(752.0, 48.0), ordered[1])
        assertEquals(Point2D(752.0, 752.0), ordered[2])
        assertEquals(Point2D(48.0, 752.0), ordered[3])
    }

    @Test
    fun testPerspectiveHomographyMapping() {
        val transformer = PerspectiveTransformer()
        val geom = BoardGeometry(
            topLeftPx = Point2D(50.0, 50.0),
            topRightPx = Point2D(650.0, 50.0),
            bottomRightPx = Point2D(650.0, 650.0),
            bottomLeftPx = Point2D(50.0, 650.0),
            imageWidth = 700,
            imageHeight = 700
        )
        val centerNorm = transformer.mapBoardPixelToNormalized(Point2D(350.0, 350.0), geom)
        assertEquals(0.50, centerNorm.x, 1e-5)
        assertEquals(0.50, centerNorm.y, 1e-5)
    }

    @Test
    fun testDistanceCalculationsPythagorean() {
        val a = Point2D(0.20, 0.30)
        val b = Point2D(0.50, 0.70)
        val dist = CoordinateMapper.calculateDistance(a, b)
        assertEquals(0.50, dist, 1e-6)
    }

    @Test
    fun testShotAngleCalculationAtan2Degrees() {
        val striker = Point2D(0.50, 0.80)
        val targetDirectlyAbove = Point2D(0.50, 0.30)
        val angleUp = CoordinateMapper.calculateShotAngleDegrees(striker, targetDirectlyAbove)
        assertEquals(-90.0, angleUp, 1e-5)

        val targetDiagonalTopLeft = Point2D(0.20, 0.50)
        val angleDiag = CoordinateMapper.calculateShotAngleDegrees(striker, targetDiagonalTopLeft)
        assertEquals(-135.0, angleDiag, 1e-5)
    }

    @Test
    fun testGhostBallContactPointAndCircleCollisionDistance() {
        val coinCenter = Point2D(0.50, 0.50)
        val pocketCenter = Point2D(0.50, 0.05) // Straight up
        val coinR = 0.029
        val strikerR = 0.038

        val ghostBall = CoordinateMapper.calculateGhostBallContactPoint(
            targetCoinCenter = coinCenter,
            desiredTargetMovePoint = pocketCenter,
            coinRadius = coinR,
            strikerRadius = strikerR
        )
        assertEquals(0.50, ghostBall.x, 1e-6)
        assertEquals(0.50 + coinR + strikerR, ghostBall.y, 1e-6)

        val strikerStart = Point2D(0.50, 0.82)
        val hitDist = collisionEngine.computeCircleCollisionDistance(
            p1 = strikerStart,
            dir = Point2D(0.0, -1.0),
            r1 = strikerR,
            p2 = coinCenter,
            r2 = coinR
        )
        assertNotNull(hitDist)
        assertEquals(0.82 - (0.50 + coinR + strikerR), hitDist!!, 1e-5)
    }

    @Test
    fun testMomentumTransferAndCollisionPhysics() {
        val strikerStart = Point2D(0.45, 0.82)
        val coinCenter = Point2D(0.32, 0.42)
        val topLeftPocket = Point2D(0.055, 0.055)
        val ghostBall = CoordinateMapper.calculateGhostBallContactPoint(
            targetCoinCenter = coinCenter,
            desiredTargetMovePoint = topLeftPocket,
            coinRadius = 0.029,
            strikerRadius = 0.038
        )

        val pred = collisionEngine.predictCollision(
            strikerStartPos = strikerStart,
            ghostBallPos = ghostBall,
            targetCoinCenter = coinCenter,
            desiredTargetMovePoint = topLeftPocket,
            coinRadius = 0.029,
            strikerRadius = 0.038,
            config = defaultConfig
        )
        assertTrue(pred.energyTransferRatio > 0.40)
        val expectedDir = (topLeftPocket - coinCenter).normalized()
        val actualCoinVelDir = pred.coinPostVelocity.normalized()
        assertEquals(expectedDir.x, actualCoinVelDir.x, 1e-4)
        assertEquals(expectedDir.y, actualCoinVelDir.y, 1e-4)
    }

    @Test
    fun testSingleAndDoubleCushionReflections() {
        val startCoin = Point2D(0.35, 0.60)
        val topRightPocket = Pocket(1, "Top-Right Pocket", 0.945, 0.055, 0.042)

        val singleBanks = cushionEngine.calculateSingleCushionPaths(
            startPoint = startCoin,
            targetPocket = topRightPocket,
            objectRadius = 0.029,
            config = defaultConfig
        )
        assertTrue("Expected at least one valid single-cushion bank path", singleBanks.isNotEmpty())
        for (bank in singleBanks) {
            assertEquals(2, bank.segments.size)
            assertTrue(bank.firstBouncePoint.x in 0.02..0.98)
            assertTrue(bank.firstBouncePoint.y in 0.02..0.98)
        }

        val doubleBanks = cushionEngine.calculateDoubleCushionPaths(
            startPoint = startCoin,
            targetPocket = topRightPocket,
            objectRadius = 0.029,
            config = defaultConfig
        )
        assertTrue("Expected at least one valid double-cushion bank path", doubleBanks.isNotEmpty())
        assertEquals(3, doubleBanks.first().segments.size)
    }

    @Test
    fun testDeceleratingTrajectorySimulation() {
        val (segments, finalPos) = trajectoryEngine.traceDeceleratingTrajectory(
            startPos = Point2D(0.50, 0.60),
            initialVelocity = Point2D(-0.85, -0.95),
            objectRadius = 0.038,
            config = defaultConfig,
            maxBounces = 2
        )
        assertTrue(segments.isNotEmpty())
        assertTrue(finalPos.x in 0.038..0.962)
        assertTrue(finalPos.y in 0.038..0.962)
    }

    @Test
    fun testObstacleDetectionAlongPath() {
        val start = Point2D(0.50, 0.80)
        val end = Point2D(0.50, 0.20)
        val blockingCoin = DetectedObject(
            id = "blocker_1",
            type = ObjectType.BLACK_COIN,
            x = 0.51,
            y = 0.50,
            radius = 0.029,
            confidence = 0.95
        )
        val clearCoin = DetectedObject(
            id = "clear_1",
            type = ObjectType.WHITE_COIN,
            x = 0.20,
            y = 0.50,
            radius = 0.029,
            confidence = 0.95
        )
        val obstacles = CoordinateMapper.findObstaclesAlongSegment(
            start = start,
            end = end,
            movingRadius = 0.029,
            allObjects = listOf(blockingCoin, clearCoin),
            excludedObjectIds = emptySet()
        )
        assertEquals(1, obstacles.size)
        assertEquals("blocker_1", obstacles.first().id)
    }

    @Test
    fun testShotAnalyzerAndRankingConfidenceCap() {
        val board = BoardGeometry(
            topLeftPx = Point2D(0.0, 0.0),
            topRightPx = Point2D(800.0, 0.0),
            bottomRightPx = Point2D(800.0, 800.0),
            bottomLeftPx = Point2D(0.0, 800.0),
            imageWidth = 800,
            imageHeight = 800
        )
        val objects = listOf(
            DetectedObject("white_1", ObjectType.WHITE_COIN, 0.22, 0.24, 0.029, 0.96),
            DetectedObject("queen_1", ObjectType.RED_QUEEN, 0.50, 0.45, 0.029, 0.97),
            DetectedObject("striker_1", ObjectType.STRIKER, 0.48, 0.82, 0.038, 0.96)
        )
        val suggestions = shotAnalyzer.analyzeAllShots(
            boardGeometry = board,
            detectedObjects = objects,
            physicsConfig = defaultConfig
        )
        assertTrue(suggestions.isNotEmpty())
        // Verify best shot has no obstacles and confidence is strictly capped <= 0.96
        val topShot = suggestions.first()
        assertTrue(topShot.obstaclesOnPath.isEmpty())
        assertTrue(topShot.confidenceScore in 0.08..0.96)
        assertFalse("Confidence must never claim 100% guarantee", topShot.confidenceScore >= 0.999)
    }
}
