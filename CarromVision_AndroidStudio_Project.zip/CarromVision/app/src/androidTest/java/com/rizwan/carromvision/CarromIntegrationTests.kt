package com.rizwan.carromvision

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.rizwan.carromvision.calibration.CalibrationManager
import com.rizwan.carromvision.capture.CaptureStatus
import com.rizwan.carromvision.capture.ScreenCaptureManager
import com.rizwan.carromvision.data.database.CarromDatabase
import com.rizwan.carromvision.data.repository.AnalysisRepository
import com.rizwan.carromvision.domain.models.ObjectType
import com.rizwan.carromvision.domain.models.PhysicsConfig
import com.rizwan.carromvision.domain.models.Point2D
import com.rizwan.carromvision.domain.usecases.AnalyzeBoardUseCase
import com.rizwan.carromvision.utils.PracticeBoardGenerator
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Android Instrumentation Integration Tests covering:
 * 1. Screenshot importing & PracticeBoard bitmap pipeline
 * 2. Full OpenCV + CPU Object Detection Pipeline (Board, Pockets, White/Black Coins, Queen, Striker)
 * 3. Manual Calibration & Object Reclassification
 * 4. Analysis Results generation
 * 5. Room Database CRUD operations
 * 6. Screen Capture MediaProjection permission lifecycle
 */
@RunWith(AndroidJUnit4::class)
class CarromIntegrationTests {

    private lateinit var database: CarromDatabase
    private lateinit var repository: AnalysisRepository
    private val analyzeBoardUseCase = AnalyzeBoardUseCase()
    private val calibrationManager = CalibrationManager()

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        database = Room.inMemoryDatabaseBuilder(context, CarromDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = AnalysisRepository(database.analysisDao())
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun testFullScreenshotDetectionAndAnalysisPipeline() = runBlocking {
        val testBitmap = PracticeBoardGenerator.createPracticeBitmap(800, 800, presetIndex = 0)
        val result = analyzeBoardUseCase.execute(
            sourceBitmap = testBitmap,
            physicsConfig = PhysicsConfig(),
            calibrationProfile = calibrationManager.getActiveProfile()
        )

        assertEquals(4, result.boardGeometry.pockets.size)
        assertTrue("Expected white coins detected", result.detectedObjects.any { it.type == ObjectType.WHITE_COIN })
        assertTrue("Expected black coins detected", result.detectedObjects.any { it.type == ObjectType.BLACK_COIN })
        assertTrue("Expected red queen detected", result.detectedObjects.any { it.type == ObjectType.RED_QUEEN })
        assertTrue("Expected striker detected", result.detectedObjects.any { it.type == ObjectType.STRIKER })
        assertTrue("Expected ranked shot suggestions", result.shotSuggestions.isNotEmpty())
    }

    @Test
    fun testManualCalibrationAndRoomHistoryPersistence() = runBlocking {
        val testBitmap = PracticeBoardGenerator.createPracticeBitmap(800, 800, presetIndex = 1)
        val result = analyzeBoardUseCase.execute(
            sourceBitmap = testBitmap,
            physicsConfig = PhysicsConfig(),
            calibrationProfile = calibrationManager.getActiveProfile()
        )

        val firstObj = result.detectedObjects.first()
        val adjustedObjects = calibrationManager.adjustObjectPosition(
            objects = result.detectedObjects,
            objectId = firstObj.id,
            newX = 0.40,
            newY = 0.40
        )
        val updatedFirst = adjustedObjects.first { it.id == firstObj.id }
        assertEquals(0.40, updatedFirst.x, 1e-5)
        assertEquals(0.40, updatedFirst.y, 1e-5)
        assertTrue(updatedFirst.isManuallyAdjusted)

        val topShot = result.shotSuggestions.first()
        val rowId = repository.saveAnalysis(
            screenshotUri = "content://carromvision/test_frame_1",
            retainScreenshot = true,
            detectedObjects = adjustedObjects,
            selectedShot = topShot,
            notes = "Integration test verification"
        )
        assertTrue(rowId > 0L)

        val storedList = repository.allAnalyses.first()
        assertEquals(1, storedList.size)
        assertEquals(topShot.targetPocket.name, storedList.first().selectedPocketName)

        repository.clearAllHistory()
        assertTrue(repository.allAnalyses.first().isEmpty())
    }

    @Test
    fun testScreenCapturePermissionLifecycle() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        val captureManager = ScreenCaptureManager(context)
        assertEquals(CaptureStatus.IDLE, captureManager.status.value)

        val intent = captureManager.createScreenCaptureIntent()
        assertNotNull(intent)
        assertEquals(CaptureStatus.PERMISSION_REQUIRED, captureManager.status.value)

        captureManager.onPermissionDenied()
        assertEquals(CaptureStatus.REVOKED_OR_ERROR, captureManager.status.value)

        captureManager.stopSession()
        assertEquals(CaptureStatus.STOPPED, captureManager.status.value)
    }
}
