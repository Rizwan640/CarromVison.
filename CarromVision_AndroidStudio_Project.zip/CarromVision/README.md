# Carrom Vision — Android Visual Analysis & Physics Aiming Assistant

**Package Name:** `com.rizwan.carromvision`  
**Platform:** Android 7.0+ (API 24 – API 34)  
**Language & UI:** Kotlin 1.9.23 + Jetpack Compose (Material 3)  
**Architecture:** MVVM + Clean Architecture  
**Computer Vision Engine:** OpenCV Android SDK 4.9.0 + Deterministic HSV/Contour Pipeline  
**Local Storage:** Room Database 2.6.1 + Jetpack DataStore Preferences 1.1.0  
**Developer Credit:** Khan Rizwan  

---

## 1. Overview & Security Architecture

**Carrom Vision** is a standalone, 100% offline, CPU-friendly visual analysis and mathematical trajectory calculation application designed for analyzing **Carrom Pool** screenshots and user-authorized screen captures.

### Strict Privacy & Fair-Play Guarantees
- **Zero Game Memory Access:** Does not read, hook, or modify any external process or game memory.
- **No Root Required:** Runs within a standard unprivileged Android application sandbox.
- **No Unauthorized Screen Overlays:** All aiming guidelines, ghost-ball contact rings, cushion rebound vectors, and striker deflection paths are rendered exclusively inside Carrom Vision's own **Analysis Workspace** (`TrajectoryRenderer`).
- **Explicit User-Initiated Screen Capture:** Uses Android's standard `MediaProjection` API with a compliant `foregroundServiceType="mediaProjection"` service (`MediaProjectionService`) that captures a single frame only when initiated by the user and stops immediately on request.
- **100% Offline Execution:** Requires no internet permission, no cloud APIs, and no account login.

---

## 2. Project Directory Structure

```text
CarromVision/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/
        ├── main/
        │   ├── AndroidManifest.xml
        │   ├── assets/
        │   │   ├── sample_carrom_board_preset_1.png
        │   │   └── sample_carrom_board_preset_2.png
        │   ├── res/
        │   │   ├── drawable/ic_launcher_foreground.xml
        │   │   └── values/ (strings.xml, themes.xml)
        │   └── java/com/rizwan/carromvision/
        │       ├── CarromVisionApp.kt
        │       ├── MainActivity.kt
        │       ├── ui/
        │       │   ├── CarromVisionViewModel.kt
        │       │   ├── theme/Theme.kt
        │       │   ├── home/HomeAndSplashScreens.kt
        │       │   ├── analysis/AnalysisWorkspaceScreen.kt
        │       │   ├── results/AnalysisResultsScreen.kt
        │       │   ├── history/HistoryScreen.kt
        │       │   └── settings/SettingsScreen.kt
        │       ├── core/
        │       │   ├── vision/
        │       │   │   ├── BoardDetector.kt
        │       │   │   ├── PerspectiveTransformer.kt
        │       │   │   ├── PocketDetector.kt
        │       │   │   ├── CoinDetector.kt
        │       │   │   └── StrikerDetector.kt
        │       │   ├── geometry/
        │       │   │   └── CoordinateMapper.kt
        │       │   ├── physics/
        │       │   │   ├── CollisionEngine.kt
        │       │   │   ├── CushionReflectionEngine.kt
        │       │   │   └── TrajectoryEngine.kt
        │       │   └── rendering/
        │       │       └── TrajectoryRenderer.kt
        │       ├── data/
        │       │   ├── database/
        │       │   │   ├── AnalysisEntity.kt
        │       │   │   ├── AnalysisDao.kt
        │       │   │   └── CarromDatabase.kt
        │       │   ├── preferences/
        │       │   │   └── UserPreferencesRepository.kt
        │       │   └── repository/
        │       │       └── AnalysisRepository.kt
        │       ├── domain/
        │       │   ├── models/CarromModels.kt
        │       │   ├── usecases/AnalyzeBoardUseCase.kt
        │       │   └── algorithms/
        │       │       ├── ShotAnalyzer.kt
        │       │       └── ShotRankingEngine.kt
        │       ├── capture/
        │       │   ├── ScreenCaptureManager.kt
        │       │   └── MediaProjectionService.kt
        │       ├── calibration/
        │       │   └── CalibrationManager.kt
        │       └── utils/
        │           └── PracticeBoardGenerator.kt
        ├── test/java/com/rizwan/carromvision/
        │   └── CarromEngineUnitTests.kt
        └── androidTest/java/com/rizwan/carromvision/
            └── CarromIntegrationTests.kt
```

---

## 3. Mathematical & Computer Vision Engine Formulations

### A. Perspective Normalization (`[0.0, 1.0]`)
1. `BoardDetector` locates the 4 playing-surface corners $(x_i, y_i)$ using Gaussian smoothing ($5\times5, \sigma=1.4$), Canny edge detection ($45, 135$), external contour polygon approximation (`approxPolyDP`), and corner sum/difference ordering (`TopLeft`, `TopRight`, `BottomRight`, `BottomLeft`).
2. `PerspectiveTransformer` computes the $3\times3$ homography matrix $H$ mapping the board quadrilateral to a flat square $[0.0, 1.0] \times [0.0, 1.0]$ coordinate space.

### B. Ghost-Ball Contact Point & Shot Angle
Given Target Coin center $\mathbf{C}_{\text{coin}}$ with radius $R_{\text{coin}}$, Striker radius $R_{\text{striker}}$, and desired target destination $\mathbf{P}_{\text{aim}}$ (either a Pocket center or Cushion bounce point):
$$\mathbf{u}_{\text{dir}} = \frac{\mathbf{P}_{\text{aim}} - \mathbf{C}_{\text{coin}}}{\|\mathbf{P}_{\text{aim}} - \mathbf{C}_{\text{coin}}\|}$$
$$\mathbf{C}_{\text{ghost}} = \mathbf{C}_{\text{coin}} - (R_{\text{coin}} + R_{\text{striker}})\,\mathbf{u}_{\text{dir}}$$
$$\theta_{\text{shot}} = \text{atan2}(C_{\text{ghost},y} - S_y,\; C_{\text{ghost},x} - S_x) \times \frac{180^\circ}{\pi}$$

### C. 2D Impulse-Momentum Transfer & Friction Deceleration
At impact between the Striker (mass ratio $m_s = 1.85$, pre-impact velocity $\mathbf{v}_{s0}$) and stationary Coin ($m_c = 1.0$), with coin-coin restitution $e_{\text{coin}}$ and contact normal $\mathbf{n} = \mathbf{u}_{\text{dir}}$:
$$v_{sn}' = \left(\frac{m_s - e_{\text{coin}} m_c}{m_s + m_c}\right) (\mathbf{v}_{s0} \cdot \mathbf{n}) \cdot \eta_{\text{damp}}, \quad v_{cn}' = \left(\frac{(1 + e_{\text{coin}}) m_s}{m_s + m_c}\right) (\mathbf{v}_{s0} \cdot \mathbf{n}) \cdot \eta_{\text{damp}}$$
Stopping distance under surface sliding friction $\mu$ is modeled as $d_{\text{stop}} = \frac{\|\mathbf{v}'\|^2}{2\mu_{\text{eff}}}$.

### D. Single & Double Cushion Mirror Reflections
For a cushion wall at effective inner boundary $b \in \{R, 1-R\}$:
- **Single Bank Shot:** Mirror the target pocket center $\mathbf{P}$ across wall $W_1$ to obtain $\mathbf{P}'$, intersect the segment $\overline{\mathbf{C}_{\text{coin}}\mathbf{P}'}$ with $W_1$ to find the exact rail bounce point $\mathbf{B}_1$, and validate that $\mathbf{B}_1$ lies within the legal cushion rail $[0.11, 0.89]$.
- **Double Bank Shot:** Mirror $\mathbf{P}$ across $W_2$ to get $\mathbf{P}'$, mirror $\mathbf{P}'$ across $W_1$ to get $\mathbf{P}''$, and solve sequential rail intersections $\mathbf{B}_1 \in W_1$ and $\mathbf{B}_2 \in W_2$.

---

## 4. Building the Debug & Release APKs and Running Tests

### Prerequisites
- **Android Studio Jellyfish (2023.3.1)+** or **Android SDK Command-Line Tools** (API 34)
- **JDK 17** (`JAVA_HOME` pointing to OpenJDK 17)

### Step-by-Step Build & Installation Commands
1. Extract `CarromVision_AndroidStudio_Project.zip` and open the `CarromVision` directory in Android Studio, or run from a terminal with `ANDROID_HOME` configured:
   ```bash
   # 1. Run all JUnit4 mathematical, physics, and vision unit tests
   ./gradlew testDebugUnitTest

   # 2. Generate the installable Debug APK
   ./gradlew assembleDebug
   # Output: app/build/outputs/apk/debug/app-debug.apk

   # 3. Generate the optimized Release APK
   ./gradlew assembleRelease
   # Output: app/build/outputs/apk/release/app-release-unsigned.apk

   # 4. Install Debug APK onto a connected Android device (Android 7.0 / API 24+)
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
